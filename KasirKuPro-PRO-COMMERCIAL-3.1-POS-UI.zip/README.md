# KasirKuPro Professional POS 3.0

Versi ini merapikan ulang struktur aplikasi agar lebih stabil dan terasa seperti kasir komersial.

Fitur utama:
- Dashboard kasir dengan pencarian produk, kategori, SKU/barcode keyboard, keranjang, diskon, pajak, dan checkout.
- Produk & stok: tambah, edit, nonaktifkan, harga modal, harga jual, SKU, minimum stok, indikator stok menipis.
- Transaksi: pencarian, filter metode pembayaran, detail transaksi, dan riwayat lokal.
- Laporan: omzet, jumlah transaksi, laba kotor, produk terjual, produk terlaris, dan stok menipis.
- Printer Bluetooth thermal 58/80 mm, koneksi perangkat yang sudah dipasangkan, tes cetak, dan cetak otomatis.
- Pengaturan toko, pajak, mode gelap, suara kasir, peringatan stok, dan backup lokal melalui penyimpanan aplikasi.
- Data produk dan transaksi disimpan lokal menggunakan SharedPreferences.

Workflow GitHub Actions melakukan `flutter analyze`, `flutter test`, dan `flutter build apk --release`.


## UI 3.1 — Commercial POS
- Drawer premium dengan ringkasan omzet dan status printer.
- Header kasir baru dengan status printer.
- Kartu produk lebih kompak seperti POS komersial.
- Pencarian + scan barcode entry point + kategori.
- Floating cart checkout dengan total transaksi yang selalu terlihat.
