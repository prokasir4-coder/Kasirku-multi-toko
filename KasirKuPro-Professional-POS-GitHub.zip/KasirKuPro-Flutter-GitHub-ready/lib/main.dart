import 'package:flutter/material.dart';

void main() => runApp(const KasirKuProApp());

const primary = Color(0xFF1D4ED8);
const background = Color(0xFFF6F8FC);

class KasirKuProApp extends StatefulWidget {
  const KasirKuProApp({super.key});

  @override
  State<KasirKuProApp> createState() => _KasirKuProAppState();
}

class _KasirKuProAppState extends State<KasirKuProApp> {
  ThemeMode themeMode = ThemeMode.light;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KasirKuPro',
      themeMode: themeMode,
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      home: MainScreen(
        onThemeChanged: (dark) => setState(
          () => themeMode = dark ? ThemeMode.dark : ThemeMode.light,
        ),
      ),
    );
  }

  ThemeData _theme(Brightness brightness) {
    final dark = brightness == Brightness.dark;
    final scheme = ColorScheme.fromSeed(
      seedColor: primary,
      brightness: brightness,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: dark ? const Color(0xFF0F172A) : background,
      cardTheme: CardThemeData(
        elevation: 0,
        color: dark ? const Color(0xFF172033) : Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF172033) : Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: scheme.primary, width: 1.5),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 74,
        backgroundColor: dark ? const Color(0xFF111827) : Colors.white,
        indicatorColor: scheme.primaryContainer,
        labelTextStyle: WidgetStatePropertyAll(
          const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
        ),
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  final ValueChanged<bool> onThemeChanged;
  const MainScreen({super.key, required this.onThemeChanged});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const DashboardPage(),
      const ProductsPage(),
      const TransactionsPage(),
      SettingsPage(onThemeChanged: widget.onThemeChanged),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.grid_view_rounded),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'Beranda',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            selectedIcon: Icon(Icons.inventory_2_rounded),
            label: 'Produk',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: 'Transaksi',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Pengaturan',
          ),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 26),
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Selamat pagi 👋',
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'KasirKuPro',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
            IconButton.filledTonal(
              onPressed: () {},
              icon: const Icon(Icons.notifications_none_rounded),
            ),
            const SizedBox(width: 8),
            const CircleAvatar(
              radius: 22,
              child: Icon(Icons.storefront_rounded),
            ),
          ],
        ),
        const SizedBox(height: 18),
        _SalesHero(),
        const SizedBox(height: 16),
        const Row(
          children: [
            Expanded(child: _Kpi(title: 'Transaksi', value: '128', icon: Icons.receipt_long_rounded, change: '+8,4%')),
            SizedBox(width: 12),
            Expanded(child: _Kpi(title: 'Produk Terjual', value: '342', icon: Icons.shopping_bag_rounded, change: '+12,1%')),
          ],
        ),
        const SizedBox(height: 22),
        const _SectionHeader(title: 'Aksi cepat', action: 'Lihat semua'),
        const SizedBox(height: 10),
        SizedBox(
          height: 102,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: const [
              _QuickAction(icon: Icons.point_of_sale_rounded, title: 'Kasir'),
              _QuickAction(icon: Icons.add_box_rounded, title: 'Produk'),
              _QuickAction(icon: Icons.inventory_rounded, title: 'Stok'),
              _QuickAction(icon: Icons.bar_chart_rounded, title: 'Laporan'),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const _SectionHeader(title: 'Stok menipis', action: 'Kelola stok'),
        const SizedBox(height: 10),
        const _StockCard(name: 'Kopi Susu Gula Aren', stock: '4 pcs', price: 'Rp 18.000'),
        const _StockCard(name: 'Mie Goreng Special', stock: '7 pcs', price: 'Rp 15.000'),
        const SizedBox(height: 14),
        const _SectionHeader(title: 'Transaksi terbaru', action: 'Lihat semua'),
        const SizedBox(height: 8),
        const _TransactionTile(code: 'TRX-00128', method: 'QRIS • 08:42', amount: 'Rp 125.000'),
        const _TransactionTile(code: 'TRX-00127', method: 'Tunai • 08:31', amount: 'Rp 340.000'),
        const _TransactionTile(code: 'TRX-00126', method: 'Transfer • 08:15', amount: 'Rp 89.500'),
      ],
    );
  }
}

class _SalesHero extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [scheme.primary, Color.alphaBlend(Colors.black.withOpacity(.12), scheme.primary)],
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(color: scheme.primary.withOpacity(.18), blurRadius: 24, offset: const Offset(0, 10)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text('Penjualan hari ini', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w600)),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(30)),
                child: const Text('Hari ini', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text('Rp 4.850.000', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Row(
            children: [
              Icon(Icons.trending_up_rounded, color: Colors.white, size: 18),
              SizedBox(width: 5),
              Text('+12,5% dibanding kemarin', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }
}

class _Kpi extends StatelessWidget {
  final String title, value, change;
  final IconData icon;
  const _Kpi({required this.title, required this.value, required this.icon, required this.change});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: Theme.of(context).colorScheme.primary, size: 20),
            ),
            const Spacer(),
            Text(change, style: TextStyle(color: Colors.green.shade700, fontWeight: FontWeight.w800, fontSize: 12)),
          ]),
          const SizedBox(height: 13),
          Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
          Text(title, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title, action;
  const _SectionHeader({required this.title, required this.action});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
          Text(action, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.w700, fontSize: 13)),
        ],
      );
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  const _QuickAction({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) => Container(
        width: 92,
        margin: const EdgeInsets.only(right: 10),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
            ]),
          ),
        ),
      );
}

class _StockCard extends StatelessWidget {
  final String name, stock, price;
  const _StockCard({required this.name, required this.stock, required this.price});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.only(bottom: 8),
        child: ListTile(
          leading: CircleAvatar(
            backgroundColor: Theme.of(context).colorScheme.errorContainer,
            child: Icon(Icons.inventory_2_rounded, color: Theme.of(context).colorScheme.error),
          ),
          title: Text(name, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(price),
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.errorContainer, borderRadius: BorderRadius.circular(10)),
            child: Text(stock, style: TextStyle(color: Theme.of(context).colorScheme.error, fontWeight: FontWeight.w800)),
          ),
        ),
      );
}

class _TransactionTile extends StatelessWidget {
  final String code, method, amount;
  const _TransactionTile({required this.code, required this.method, required this.amount});

  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 4),
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
          child: Icon(Icons.receipt_long_rounded, color: Theme.of(context).colorScheme.primary),
        ),
        title: Text(code, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(method),
        trailing: Text(amount, style: const TextStyle(fontWeight: FontWeight.w900)),
      );
}

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});
  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final search = TextEditingController();
  String category = 'Semua';

  final products = const [
    ('Kopi Susu', 'Minuman', 'Rp 18.000', '42'),
    ('Mie Goreng', 'Makanan', 'Rp 15.000', '28'),
    ('Air Mineral', 'Minuman', 'Rp 5.000', '96'),
    ('Teh Manis', 'Minuman', 'Rp 7.000', '55'),
    ('Nasi Ayam', 'Makanan', 'Rp 22.000', '16'),
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = products.where((p) {
      final q = search.text.toLowerCase();
      return (category == 'Semua' || p.$2 == category) && p.$1.toLowerCase().contains(q);
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      children: [
        const Text('Produk', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
        const SizedBox(height: 4),
        Text('Kelola katalog, harga, dan stok.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        const SizedBox(height: 18),
        TextField(
          controller: search,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(hintText: 'Cari nama produk...', prefixIcon: Icon(Icons.search_rounded)),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 42,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: ['Semua', 'Makanan', 'Minuman'].map((item) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(item),
                  selected: category == item,
                  onSelected: (_) => setState(() => category = item),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 14),
        ...filtered.map((p) => Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                leading: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(14)),
                  child: Icon(Icons.fastfood_rounded, color: Theme.of(context).colorScheme.primary),
                ),
                title: Text(p.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${p.$2} • Stok ${p.$4}'),
                trailing: Text(p.$3, style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            )),
      ],
    );
  }
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
        children: [
          const Text('Transaksi', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('Riwayat penjualan dan pembayaran.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _SummaryBox(title: 'Hari ini', value: 'Rp 4,85 jt')),
            const SizedBox(width: 10),
            Expanded(child: _SummaryBox(title: 'Transaksi', value: '128')),
          ]),
          const SizedBox(height: 18),
          const _TransactionTile(code: 'TRX-00128', method: 'QRIS • Hari ini 08:42', amount: 'Rp 125.000'),
          const _TransactionTile(code: 'TRX-00127', method: 'Tunai • Hari ini 08:31', amount: 'Rp 340.000'),
          const _TransactionTile(code: 'TRX-00126', method: 'Transfer • Hari ini 08:15', amount: 'Rp 89.500'),
          const _TransactionTile(code: 'TRX-00125', method: 'Kartu • Kemarin 20:04', amount: 'Rp 215.000'),
          const _TransactionTile(code: 'TRX-00124', method: 'QRIS • Kemarin 19:42', amount: 'Rp 76.000'),
        ],
      );
}

class _SummaryBox extends StatelessWidget {
  final String title, value;
  const _SummaryBox({required this.title, required this.value});
  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          ]),
        ),
      );
}

class SettingsPage extends StatefulWidget {
  final ValueChanged<bool> onThemeChanged;
  const SettingsPage({super.key, required this.onThemeChanged});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String storeName = 'Toko Utama';
  String ownerName = 'Pemilik Toko';
  String phone = '0812 3456 7890';
  String address = 'Jl. Contoh No. 10, Indonesia';
  bool darkMode = false;
  bool lowStock = true;
  bool autoPrint = true;
  bool taxEnabled = true;
  bool receiptLogo = true;
  bool soundEnabled = true;
  int taxPercent = 11;
  String printer = 'Belum terhubung';

  void _profile() {
    final name = TextEditingController(text: storeName);
    final owner = TextEditingController(text: ownerName);
    final phoneCtl = TextEditingController(text: phone);
    final addressCtl = TextEditingController(text: address);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => Padding(
        padding: EdgeInsets.fromLTRB(20, 4, 20, MediaQuery.of(sheet).viewInsets.bottom + 24),
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Profil Toko', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            const Text('Informasi toko yang digunakan di dashboard dan struk.'),
            const SizedBox(height: 18),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nama toko', prefixIcon: Icon(Icons.storefront_outlined))),
            const SizedBox(height: 10),
            TextField(controller: owner, decoration: const InputDecoration(labelText: 'Pemilik toko', prefixIcon: Icon(Icons.person_outline))),
            const SizedBox(height: 10),
            TextField(controller: phoneCtl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Nomor telepon', prefixIcon: Icon(Icons.phone_outlined))),
            const SizedBox(height: 10),
            TextField(controller: addressCtl, minLines: 2, maxLines: 3, decoration: const InputDecoration(labelText: 'Alamat toko', prefixIcon: Icon(Icons.location_on_outlined))),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () {
                setState(() {
                  storeName = name.text.trim().isEmpty ? 'Toko Utama' : name.text.trim();
                  ownerName = owner.text.trim().isEmpty ? 'Pemilik Toko' : owner.text.trim();
                  phone = phoneCtl.text.trim();
                  address = addressCtl.text.trim();
                });
                Navigator.pop(sheet);
              },
              icon: const Icon(Icons.check_rounded),
              label: const Text('Simpan perubahan'),
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
            ),
          ]),
        ),
      ),
    );
  }

  void _info(String title, String message) => showDialog<void>(
        context: context,
        builder: (dialog) => AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: [TextButton(onPressed: () => Navigator.pop(dialog), child: const Text('Tutup'))],
        ),
      );

  Widget _section(String title, String subtitle) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          Text(subtitle, style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurfaceVariant)),
        ]),
      );

  Widget _tile({required IconData icon, required String title, String? subtitle, VoidCallback? onTap, Widget? trailing}) => ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: Icon(icon, color: Theme.of(context).colorScheme.primary),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: subtitle == null ? null : Text(subtitle),
        trailing: trailing ?? (onTap == null ? null : const Icon(Icons.chevron_right_rounded)),
      );

  Widget _card(List<Widget> children) => Card(
        clipBehavior: Clip.antiAlias,
        margin: EdgeInsets.zero,
        child: Column(children: children),
      );

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 28),
      children: [
        Row(children: [
          const Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Pengaturan', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
              SizedBox(height: 4),
              Text('Kelola toko, kasir, transaksi, dan sistem.'),
            ]),
          ),
          IconButton.filledTonal(onPressed: _profile, icon: const Icon(Icons.settings_rounded)),
        ]),
        const SizedBox(height: 18),
        Card(
          child: InkWell(
            onTap: _profile,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                CircleAvatar(
                  radius: 29,
                  backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                  child: Icon(Icons.storefront_rounded, color: Theme.of(context).colorScheme.primary, size: 28),
                ),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(storeName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text('$ownerName • $phone'),
                  const SizedBox(height: 5),
                  Text(address, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                ])),
                const Icon(Icons.edit_rounded),
              ]),
            ),
          ),
        ),
        _section('Toko', 'Identitas dan perangkat operasional toko.'),
        _card([
          _tile(icon: Icons.store_outlined, title: 'Profil Toko', subtitle: '$storeName • $phone', onTap: _profile),
          const Divider(height: 1),
          _tile(icon: Icons.print_outlined, title: 'Printer & Struk', subtitle: '$printer • ${autoPrint ? 'Cetak otomatis' : 'Manual'}', onTap: () => _info('Printer & Struk', 'Hubungkan printer thermal Bluetooth/USB pada versi produksi.')),
          const Divider(height: 1),
          _tile(icon: Icons.payments_outlined, title: 'Metode Pembayaran', subtitle: 'Tunai, QRIS, transfer, kartu', onTap: () => _info('Metode Pembayaran', 'Atur metode pembayaran yang tersedia di kasir.')),
        ]),
        _section('Penjualan', 'Aturan harga, pajak, diskon, dan notifikasi.'),
        _card([
          _tile(icon: Icons.percent_rounded, title: 'Pajak & Diskon', subtitle: taxEnabled ? 'Pajak aktif $taxPercent%' : 'Pajak nonaktif', onTap: () => _info('Pajak & Diskon', 'Pajak saat ini $taxPercent%. Pengaturan diskon dapat dikembangkan di halaman transaksi.')),
          const Divider(height: 1),
          _tile(icon: Icons.notifications_active_outlined, title: 'Peringatan Stok', subtitle: lowStock ? 'Notifikasi stok menipis aktif' : 'Notifikasi stok menipis nonaktif', trailing: Switch.adaptive(value: lowStock, onChanged: (v) => setState(() => lowStock = v))),
          const Divider(height: 1),
          _tile(icon: Icons.volume_up_outlined, title: 'Suara Kasir', subtitle: soundEnabled ? 'Suara transaksi aktif' : 'Suara dimatikan', trailing: Switch.adaptive(value: soundEnabled, onChanged: (v) => setState(() => soundEnabled = v))),
        ]),
        _section('Akses & Data', 'Kelola pengguna, keamanan, dan pencadangan.'),
        _card([
          _tile(icon: Icons.badge_outlined, title: 'Pengguna & Kasir', subtitle: '1 pemilik • 2 kasir', onTap: () => _info('Pengguna & Kasir', 'Atur role pemilik dan kasir serta hak akses menu.')),
          const Divider(height: 1),
          _tile(icon: Icons.lock_outline_rounded, title: 'Keamanan & PIN', subtitle: 'PIN kasir dan penguncian aplikasi', onTap: () => _info('Keamanan & PIN', 'Atur PIN kasir dan auto-lock untuk keamanan transaksi.')),
          const Divider(height: 1),
          _tile(icon: Icons.cloud_upload_outlined, title: 'Backup & Pulihkan', subtitle: 'Simpan data produk dan transaksi', onTap: () => _info('Backup & Pulihkan', 'Hubungkan penyimpanan lokal atau cloud untuk backup berkala.')),
        ]),
        _section('Tampilan', 'Buat aplikasi nyaman dipakai sepanjang hari.'),
        _card([
          _tile(icon: Icons.dark_mode_outlined, title: 'Mode Gelap', subtitle: darkMode ? 'Tampilan gelap aktif' : 'Tampilan terang aktif', trailing: Switch.adaptive(value: darkMode, onChanged: (v) { setState(() => darkMode = v); widget.onThemeChanged(v); })),
          const Divider(height: 1),
          _tile(icon: Icons.receipt_long_outlined, title: 'Format Struk', subtitle: receiptLogo ? 'Logo + detail toko + total' : 'Tanpa logo', onTap: () => setState(() => receiptLogo = !receiptLogo)),
        ]),
        _section('Aplikasi', 'Informasi dan dukungan KasirKuPro.'),
        _card([
          _tile(icon: Icons.info_outline_rounded, title: 'Tentang KasirKuPro', subtitle: 'Versi 1.1.0 • Professional POS', onTap: () => _info('KasirKuPro', 'POS modern untuk mengelola produk, transaksi, stok, dan operasional toko.')),
          const Divider(height: 1),
          _tile(icon: Icons.help_outline_rounded, title: 'Bantuan & Dukungan', subtitle: 'Panduan penggunaan aplikasi', onTap: () => _info('Bantuan & Dukungan', 'Tambahkan WhatsApp, email, dan pusat bantuan toko di sini.')),
        ]),
        const SizedBox(height: 16),
        Center(child: Text('KasirKuPro • Professional POS', style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant))),
      ],
    );
  }
}
