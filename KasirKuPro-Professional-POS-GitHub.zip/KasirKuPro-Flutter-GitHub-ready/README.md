# KasirKuPro Professional POS

UI kasir modern berbasis Flutter, siap di-upload ke GitHub dan dibuild menjadi APK melalui GitHub Actions.

## Fitur UI
- Dashboard penjualan modern
- KPI transaksi dan produk terjual
- Aksi cepat kasir, produk, stok, laporan
- Monitoring stok menipis
- Riwayat transaksi
- Pencarian dan filter produk
- Pengaturan toko profesional
- Printer & struk
- Pajak & diskon
- Pengguna & kasir
- Keamanan & PIN
- Backup & pulihkan
- Mode gelap
- Build APK otomatis via GitHub Actions

## Build APK
1. Upload seluruh isi folder project ke repository GitHub.
2. Buka **Actions**.
3. Jalankan **Build KasirKuPro APK** atau push ke branch `main`.
4. Setelah selesai, download artifact **KasirKuPro-release-apk**.
