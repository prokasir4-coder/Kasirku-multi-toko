# KasirKuPro Professional POS v2

Versi ini menghapus seluruh data demo dan menambahkan pengaturan printer thermal Bluetooth.

## Printer
- Mendukung printer thermal Bluetooth yang sudah dipasangkan di Android.
- Menu **Pengaturan > Printer & Struk** otomatis membaca perangkat yang sudah paired.
- Pilih printer, hubungkan, lalu gunakan **Cetak tes**.
- Pilihan kertas 58 mm / 80 mm.
- Opsi cetak otomatis.
- Status koneksi printer ditampilkan.

> Untuk Android, pasangan printer dilakukan terlebih dahulu melalui Pengaturan Bluetooth HP. Setelah itu tekan **Cari perangkat printer** di aplikasi.

## GitHub Actions
Workflow membuat project Android Flutter pada saat build, menjalankan analyze + test, lalu menghasilkan APK release di Artifacts.
