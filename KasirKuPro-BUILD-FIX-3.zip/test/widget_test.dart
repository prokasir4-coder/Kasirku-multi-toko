import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('KasirKuPro starts', (tester) async {
    await tester.pumpWidget(const KasirKuProApp());
    await tester.pump();
    expect(find.text('KasirKuPro'), findsOneWidget);
  });
}
