# KasirKuPro Professional POS

Flutter POS modern tanpa data demo. Fitur utama: produk, dashboard, pengaturan, printer thermal Bluetooth, cetak tes, cetak otomatis, dan pilihan kertas 58/80 mm.

## GitHub
Ekstrak ZIP dan upload seluruh isinya langsung ke root repository. GitHub Actions akan membuat project Android, mengambil dependency, menjalankan analyze/test, lalu membuat APK release.

## Printer
Pasangkan printer thermal Bluetooth terlebih dahulu di Pengaturan Bluetooth Android. Buka KasirKuPro > Pengaturan > Printer & Struk > Cari perangkat printer.
