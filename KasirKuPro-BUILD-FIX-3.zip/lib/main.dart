import 'package:flutter/material.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color brand = Color(0xFF3156D3);

void main() {
  runApp(const KasirKuProApp());
}

class KasirKuProApp extends StatefulWidget {
  const KasirKuProApp({super.key});

  @override
  State<KasirKuProApp> createState() => _KasirKuProAppState();
}

class _KasirKuProAppState extends State<KasirKuProApp> {
  ThemeMode themeMode = ThemeMode.light;
  String storeName = 'Nama Toko';

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      themeMode = (prefs.getBool('dark') ?? false)
          ? ThemeMode.dark
          : ThemeMode.light;
      storeName = prefs.getString('store') ?? 'Nama Toko';
    });
  }

  Future<void> setDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark', value);
    if (!mounted) return;
    setState(() {
      themeMode = value ? ThemeMode.dark : ThemeMode.light;
    });
  }

  Future<void> setStoreName(String value) async {
    final name = value.trim().isEmpty ? 'Nama Toko' : value.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('store', name);
    if (!mounted) return;
    setState(() {
      storeName = name;
    });
  }

  ThemeData makeTheme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(
      seedColor: brand,
      brightness: brightness,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: brightness == Brightness.dark
          ? const Color(0xFF0B1020)
          : const Color(0xFFF6F8FC),
      cardTheme: CardThemeData(
        elevation: 0,
        color: brightness == Brightness.dark
            ? const Color(0xFF151C30)
            : Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KasirKuPro',
      theme: makeTheme(Brightness.light),
      darkTheme: makeTheme(Brightness.dark),
      themeMode: themeMode,
      home: MainShell(
        storeName: storeName,
        onDarkMode: setDarkMode,
        onStoreName: setStoreName,
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.storeName,
    required this.onDarkMode,
    required this.onStoreName,
  });

  final String storeName;
  final ValueChanged<bool> onDarkMode;
  final ValueChanged<String> onStoreName;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selectedIndex = 0;
  final List<Product> products = <Product>[];

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      Dashboard(
        storeName: widget.storeName,
        productCount: products.length,
        openProducts: () => setState(() => selectedIndex = 1),
      ),
      ProductsPage(products: products, refresh: () => setState(() {})),
      const TransactionsPage(),
      SettingsPage(
        storeName: widget.storeName,
        onDarkMode: widget.onDarkMode,
        onStoreName: widget.onStoreName,
      ),
    ];

    return Scaffold(
      body: SafeArea(child: pages[selectedIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) {
          setState(() => selectedIndex = value);
        },
        destinations: const <NavigationDestination>[
          NavigationDestination(
            icon: Icon(Icons.grid_view_outlined),
            selectedIcon: Icon(Icons.grid_view_rounded),
            label: 'Beranda',
          ),
          NavigationDestination(
            icon: Icon(Icons.inventory_2_outlined),
            selectedIcon: Icon(Icons.inventory_2_rounded),
            label: 'Produk',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: 'Transaksi',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Pengaturan',
          ),
        ],
      ),
    );
  }
}

class Product {
  Product({
    required this.name,
    required this.category,
    required this.price,
    required this.stock,
  });

  final String name;
  final String category;
  final int price;
  final int stock;
}

class Dashboard extends StatelessWidget {
  const Dashboard({
    super.key,
    required this.storeName,
    required this.productCount,
    required this.openProducts,
  });

  final String storeName;
  final int productCount;
  final VoidCallback openProducts;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.all(18),
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Selamat datang',
                    style: TextStyle(
                      color: colorScheme.onSurfaceVariant,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    storeName,
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
            IconButton.filledTonal(
              onPressed: () {},
              icon: const Icon(Icons.notifications_none_rounded),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: colorScheme.primary,
            borderRadius: BorderRadius.circular(24),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Penjualan hari ini',
                style: TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.w700,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Rp 0',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 34,
                  fontWeight: FontWeight.w900,
                ),
              ),
              SizedBox(height: 6),
              Text(
                'Belum ada transaksi hari ini',
                style: TextStyle(color: Colors.white70),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: <Widget>[
            Expanded(child: KpiCard(title: 'Transaksi', value: '0', icon: Icons.receipt_long_rounded)),
            const SizedBox(width: 10),
            Expanded(child: KpiCard(title: 'Produk', value: '$productCount', icon: Icons.inventory_2_rounded)),
          ],
        ),
        const SizedBox(height: 22),
        Row(
          children: <Widget>[
            const Expanded(
              child: Text(
                'Aksi cepat',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ),
            TextButton.icon(
              onPressed: openProducts,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Tambah produk'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: colorScheme.primaryContainer,
              child: Icon(Icons.point_of_sale_rounded, color: colorScheme.primary),
            ),
            title: const Text('Mulai transaksi', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('Tambahkan produk untuk mulai berjualan'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: openProducts,
          ),
        ),
        const SizedBox(height: 18),
        const EmptyCard(
          icon: Icons.receipt_long_outlined,
          title: 'Belum ada transaksi',
          text: 'Transaksi penjualan akan muncul di sini.',
        ),
      ],
    );
  }
}

class KpiCard extends StatelessWidget {
  const KpiCard({super.key, required this.title, required this.value, required this.icon});

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon, color: color),
            const SizedBox(height: 12),
            Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            Text(title, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

class EmptyCard extends StatelessWidget {
  const EmptyCard({super.key, required this.icon, required this.title, required this.text});

  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: <Widget>[
            Icon(icon, size: 44, color: Theme.of(context).colorScheme.onSurfaceVariant),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(text, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key, required this.products, required this.refresh});

  final List<Product> products;
  final VoidCallback refresh;

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final searchController = TextEditingController();
  String search = '';

  Future<void> addProduct() async {
    final nameController = TextEditingController();
    final priceController = TextEditingController();
    final stockController = TextEditingController();
    String category = 'Umum';

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Padding(
              padding: EdgeInsets.fromLTRB(
                20,
                8,
                20,
                MediaQuery.of(context).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    const Text('Tambah Produk', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 16),
                    TextField(controller: nameController, decoration: const InputDecoration(labelText: 'Nama produk')),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      initialValue: category,
                      decoration: const InputDecoration(labelText: 'Kategori'),
                      items: const <String>['Umum', 'Makanan', 'Minuman', 'Jasa']
                          .map((value) => DropdownMenuItem<String>(value: value, child: Text(value)))
                          .toList(),
                      onChanged: (value) {
                        if (value != null) setSheetState(() => category = value);
                      },
                    ),
                    const SizedBox(height: 10),
                    TextField(controller: priceController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Harga')),
                    const SizedBox(height: 10),
                    TextField(controller: stockController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stok awal')),
                    const SizedBox(height: 18),
                    FilledButton(
                      onPressed: () {
                        final name = nameController.text.trim();
                        final price = int.tryParse(priceController.text) ?? 0;
                        final stock = int.tryParse(stockController.text) ?? 0;
                        if (name.isEmpty || price <= 0) return;
                        widget.products.add(Product(name: name, category: category, price: price, stock: stock));
                        Navigator.of(sheetContext).pop(true);
                      },
                      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                      child: const Text('Simpan Produk'),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    if (result == true && mounted) {
      widget.refresh();
      setState(() {});
    }
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final list = widget.products.where((product) {
      return product.name.toLowerCase().contains(search.toLowerCase());
    }).toList();

    return ListView(
      padding: const EdgeInsets.all(18),
      children: <Widget>[
        Row(
          children: <Widget>[
            const Expanded(child: Text('Produk', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900))),
            FilledButton.icon(onPressed: addProduct, icon: const Icon(Icons.add), label: const Text('Tambah')),
          ],
        ),
        const SizedBox(height: 4),
        Text('Kelola produk dan stok.', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
        const SizedBox(height: 18),
        TextField(
          controller: searchController,
          onChanged: (value) => setState(() => search = value),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Cari produk...'),
        ),
        const SizedBox(height: 14),
        if (list.isEmpty)
          const EmptyCard(
            icon: Icons.inventory_2_outlined,
            title: 'Belum ada produk',
            text: 'Tambahkan produk pertama untuk mulai menggunakan kasir.',
          )
        else
          ...list.map(
            (product) => Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                  child: Icon(Icons.inventory_2_rounded, color: Theme.of(context).colorScheme.primary),
                ),
                title: Text(product.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${product.category} • Stok ${product.stock}'),
                trailing: Text('Rp ${formatMoney(product.price)}', style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
          ),
      ],
    );
  }
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: const <Widget>[
        Text('Transaksi', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
        SizedBox(height: 4),
        Text('Riwayat penjualan tersimpan di sini.'),
        SizedBox(height: 18),
        EmptyCard(
          icon: Icons.receipt_long_outlined,
          title: 'Belum ada transaksi',
          text: 'Detail transaksi akan tampil setelah penjualan pertama.',
        ),
      ],
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    super.key,
    required this.storeName,
    required this.onDarkMode,
    required this.onStoreName,
  });

  final String storeName;
  final ValueChanged<bool> onDarkMode;
  final ValueChanged<String> onStoreName;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool lowStock = true;
  bool sound = true;
  bool dark = false;
  String printer = 'Belum terhubung';
  String paper = '58 mm';
  bool autoPrint = false;

  Future<void> editStore() async {
    final controller = TextEditingController(text: widget.storeName);
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) {
        return Padding(
          padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.of(context).viewInsets.bottom + 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text('Profil Toko', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
              const SizedBox(height: 16),
              TextField(controller: controller, decoration: const InputDecoration(labelText: 'Nama toko', prefixIcon: Icon(Icons.storefront_outlined))),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                child: const Text('Simpan'),
              ),
            ],
          ),
        );
      },
    );
    if (saved == true) widget.onStoreName(controller.text);
  }

  void showInfo(String title, String message) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Tutup')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: <Widget>[
        Row(
          children: <Widget>[
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('Pengaturan', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
                  SizedBox(height: 4),
                  Text('Kelola toko, kasir, transaksi, dan sistem.'),
                ],
              ),
            ),
            IconButton.filledTonal(onPressed: editStore, icon: const Icon(Icons.edit_rounded)),
          ],
        ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            onTap: editStore,
            leading: const CircleAvatar(radius: 28, child: Icon(Icons.storefront_rounded)),
            title: Text(widget.storeName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            subtitle: const Text('Profil toko'),
            trailing: const Icon(Icons.chevron_right_rounded),
          ),
        ),
        sectionTitle('Perangkat', 'Printer dan perangkat kasir.'),
        Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: <Widget>[
              SettingsTile(
                icon: Icons.print_rounded,
                title: 'Printer & Struk',
                subtitle: '$printer • $paper • ${autoPrint ? 'Otomatis' : 'Manual'}',
                onTap: () async {
                  await Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (context) => PrinterSettingsPage(
                        initialPrinter: printer,
                        initialPaper: paper,
                        initialAuto: autoPrint,
                        onSaved: (name, width, automatic) {
                          setState(() {
                            printer = name;
                            paper = width;
                            autoPrint = automatic;
                          });
                        },
                      ),
                    ),
                  );
                },
              ),
              const Divider(height: 1),
              SettingsTile(
                icon: Icons.payments_outlined,
                title: 'Metode Pembayaran',
                subtitle: 'Tunai • QRIS • Transfer • Kartu',
                onTap: () => showInfo('Metode Pembayaran', 'Pilih metode pembayaran yang tersedia di kasir.'),
              ),
            ],
          ),
        ),
        sectionTitle('Penjualan', 'Aturan harga dan operasional.'),
        Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: <Widget>[
              SettingsTile(
                icon: Icons.percent_rounded,
                title: 'Pajak & Diskon',
                subtitle: 'Atur pajak dan diskon saat transaksi',
                onTap: () => showInfo('Pajak & Diskon', 'Pengaturan pajak dan diskon siap digunakan.'),
              ),
              const Divider(height: 1),
              SettingsTile(
                icon: Icons.notifications_active_outlined,
                title: 'Peringatan Stok',
                subtitle: lowStock ? 'Notifikasi stok menipis aktif' : 'Nonaktif',
                trailing: Switch.adaptive(value: lowStock, onChanged: (value) => setState(() => lowStock = value)),
              ),
              const Divider(height: 1),
              SettingsTile(
                icon: Icons.volume_up_outlined,
                title: 'Suara Kasir',
                subtitle: sound ? 'Suara aktif' : 'Suara nonaktif',
                trailing: Switch.adaptive(value: sound, onChanged: (value) => setState(() => sound = value)),
              ),
            ],
          ),
        ),
        sectionTitle('Tampilan & Data', 'Personalisasi dan keamanan data.'),
        Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: <Widget>[
              SettingsTile(
                icon: Icons.dark_mode_outlined,
                title: 'Mode Gelap',
                subtitle: dark ? 'Aktif' : 'Terang',
                trailing: Switch.adaptive(
                  value: dark,
                  onChanged: (value) {
                    setState(() => dark = value);
                    widget.onDarkMode(value);
                  },
                ),
              ),
              const Divider(height: 1),
              SettingsTile(
                icon: Icons.badge_outlined,
                title: 'Pengguna & Kasir',
                subtitle: 'Atur akses pemilik dan kasir',
                onTap: () => showInfo('Pengguna & Kasir', 'Modul pengguna siap dikembangkan sesuai kebutuhan toko.'),
              ),
              const Divider(height: 1),
              SettingsTile(
                icon: Icons.backup_outlined,
                title: 'Backup & Pulihkan',
                subtitle: 'Cadangkan data aplikasi',
                onTap: () => showInfo('Backup & Pulihkan', 'Gunakan fitur backup untuk menjaga data toko.'),
              ),
            ],
          ),
        ),
        sectionTitle('Aplikasi', 'Informasi aplikasi.'),
        Card(
          clipBehavior: Clip.antiAlias,
          child: SettingsTile(
            icon: Icons.info_outline_rounded,
            title: 'Tentang',
            subtitle: 'KasirKuPro Professional POS • 2.1.0',
            onTap: () => showInfo('KasirKuPro', 'Aplikasi kasir modern tanpa data demo.'),
          ),
        ),
      ],
    );
  }
}

Widget sectionTitle(String title, String subtitle) {
  return Padding(
    padding: const EdgeInsets.fromLTRB(4, 20, 4, 10),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 3),
        Text(subtitle, style: const TextStyle(fontSize: 13)),
      ],
    ),
  );
}

class SettingsTile extends StatelessWidget {
  const SettingsTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
    this.trailing,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      leading: CircleAvatar(
        backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
        child: Icon(icon, color: Theme.of(context).colorScheme.primary),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text(subtitle),
      trailing: trailing ?? (onTap == null ? null : const Icon(Icons.chevron_right_rounded)),
    );
  }
}

class PrinterSettingsPage extends StatefulWidget {
  const PrinterSettingsPage({
    super.key,
    required this.initialPrinter,
    required this.initialPaper,
    required this.initialAuto,
    required this.onSaved,
  });

  final String initialPrinter;
  final String initialPaper;
  final bool initialAuto;
  final void Function(String, String, bool) onSaved;

  @override
  State<PrinterSettingsPage> createState() => _PrinterSettingsPageState();
}

class _PrinterSettingsPageState extends State<PrinterSettingsPage> {
  List<BluetoothInfo> devices = <BluetoothInfo>[];
  bool loading = false;
  bool connected = false;
  bool automatic = false;
  String paper = '58 mm';
  String? selected;

  @override
  void initState() {
    super.initState();
    automatic = widget.initialAuto;
    paper = widget.initialPaper;
    selected = widget.initialPrinter == 'Belum terhubung' ? null : widget.initialPrinter;
    checkConnection();
  }

  Future<void> checkConnection() async {
    try {
      final status = await PrintBluetoothThermal.connectionStatus;
      if (mounted) setState(() => connected = status);
    } catch (_) {}
  }

  Future<void> scanPrinters() async {
    setState(() => loading = true);
    try {
      final permission = await PrintBluetoothThermal.isPermissionBluetoothGranted;
      final enabled = await PrintBluetoothThermal.bluetoothEnabled;
      if (!permission) {
        showMessage('Izinkan akses Perangkat Terdekat untuk Bluetooth.');
      } else if (!enabled) {
        showMessage('Nyalakan Bluetooth lalu cari perangkat lagi.');
      } else {
        final result = await PrintBluetoothThermal.pairedBluetooths;
        if (mounted) setState(() => devices = result);
      }
    } catch (error) {
      showMessage('Tidak dapat membaca Bluetooth: $error');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> connectPrinter(BluetoothInfo device) async {
    final mac = device.macAdress.trim();
    if (mac.isEmpty) {
      showMessage('Alamat Bluetooth printer tidak tersedia.');
      return;
    }

    try {
      final result = await PrintBluetoothThermal.connect(macPrinterAddress: mac);
      if (!result) {
        showMessage('Gagal terhubung. Pastikan printer sudah dipasangkan di Bluetooth HP.');
        return;
      }

      final name = device.name.trim().isEmpty ? mac : device.name.trim();
      setState(() {
        connected = true;
        selected = name;
      });
      widget.onSaved(name, paper, automatic);
      showMessage('Printer terhubung.');
    } catch (error) {
      showMessage('Gagal terhubung: $error');
    }
  }

  Future<void> printTest() async {
    if (!connected) {
      showMessage('Hubungkan printer terlebih dahulu.');
      return;
    }

    try {
      final first = await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(size: 2, text: 'KASIRKUPRO\n'),
      );
      final second = await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(size: 1, text: 'Tes printer berhasil\n$paper\n\n'),
      );
      showMessage(first && second ? 'Cetak tes berhasil.' : 'Cetak tes gagal.');
    } catch (error) {
      showMessage('Cetak tes gagal: $error');
    }
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Printer & Struk', style: TextStyle(fontWeight: FontWeight.w900)),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
        children: <Widget>[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                        child: Icon(Icons.print_rounded, color: Theme.of(context).colorScheme.primary),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              connected ? 'Printer terhubung' : 'Belum terhubung',
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                            ),
                            Text(selected ?? 'Pilih printer thermal Bluetooth'),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: loading ? null : scanPrinters,
                    icon: loading
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.bluetooth_searching_rounded),
                    label: Text(loading ? 'Mencari...' : 'Cari perangkat printer'),
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: connected ? printTest : null,
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('Cetak tes'),
                    style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Perangkat yang sudah dipasangkan', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          if (devices.isEmpty)
            const EmptyCard(
              icon: Icons.bluetooth_disabled_rounded,
              title: 'Belum ada perangkat',
              text: 'Pasangkan printer di Pengaturan Bluetooth HP, lalu tekan Cari perangkat.',
            )
          else
            ...devices.map(
              (device) {
                final label = device.name.trim().isEmpty ? device.macAdress : device.name.trim();
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.print_rounded)),
                    title: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(device.macAdress),
                    trailing: FilledButton(
                      onPressed: () => connectPrinter(device),
                      child: Text(selected == label ? 'Terhubung' : 'Pilih'),
                    ),
                  ),
                );
              },
            ),
          const SizedBox(height: 18),
          Card(
            child: Column(
              children: <Widget>[
                SettingsTile(
                  icon: Icons.auto_awesome_rounded,
                  title: 'Cetak otomatis',
                  subtitle: 'Cetak struk setelah transaksi selesai',
                  trailing: Switch.adaptive(
                    value: automatic,
                    onChanged: (value) {
                      setState(() => automatic = value);
                      widget.onSaved(selected ?? 'Belum terhubung', paper, automatic);
                    },
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.straighten_rounded),
                  title: const Text('Ukuran kertas', style: TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('Thermal $paper'),
                  trailing: DropdownButton<String>(
                    value: paper,
                    items: const <String>['58 mm', '80 mm']
                        .map((value) => DropdownMenuItem<String>(value: value, child: Text(value)))
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() => paper = value);
                      widget.onSaved(selected ?? 'Belum terhubung', paper, automatic);
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String formatMoney(int value) {
  return value.toString().replaceAllMapped(
        RegExp(r'(?=(\d{3})+(?!\d))'),
        (_) => '.',
      );
}
