# KasirKuPro Professional POS

Aplikasi kasir Flutter Android dengan UI modern, tanpa data demo, dan dukungan printer thermal Bluetooth.

## Build GitHub Actions
1. Upload seluruh isi repository ini ke GitHub (bukan file ZIP sebagai satu file).
2. Commit ke branch `main`.
3. Buka **Actions**.
4. Pilih **Build KasirKuPro APK**.
5. Download artifact **KasirKuPro-release-apk** setelah build selesai.

Workflow membuat folder Android otomatis sebelum build.

## Printer
Pasangkan printer thermal Bluetooth melalui Pengaturan Bluetooth Android terlebih dahulu.
Lalu buka **Pengaturan → Printer & Struk → Cari perangkat printer**, pilih printer, dan gunakan **Cetak tes**.

Package printer dipin ke `1.1.7`, yang menyatakan kompatibel dengan Flutter 3.35.5 dan Android 5.0+.
