import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('KasirKuPro opens without demo data', (tester) async {
    await tester.pumpWidget(const KasirKuProApp());
    await tester.pump();
    expect(find.text('Penjualan hari ini'), findsOneWidget);
    expect(find.text('Belum ada transaksi hari ini'), findsOneWidget);
  });
}
