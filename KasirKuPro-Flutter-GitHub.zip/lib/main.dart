import 'package:flutter/material.dart';

void main() {
  runApp(const KasirKuProApp());
}

class KasirKuProApp extends StatelessWidget {
  const KasirKuProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KasirKuPro',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        scaffoldBackgroundColor: const Color(0xFFF6F8FC),
        fontFamily: 'sans',
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    ProductsPage(),
    TransactionsPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Produk'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transaksi'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Pengaturan'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('KasirKuPro', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                  SizedBox(height: 4),
                  Text('Toko Utama', style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            CircleAvatar(
              radius: 22,
              child: Icon(Icons.storefront),
            ),
          ],
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: Theme.of(context).colorScheme.primary,
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Penjualan Hari Ini', style: TextStyle(color: Colors.white70)),
              SizedBox(height: 8),
              Text('Rp 4.850.000', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
              SizedBox(height: 8),
              Text('+12,5% dari kemarin', style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const Row(
          children: [
            Expanded(child: StatCard(title: 'Transaksi', value: '128', icon: Icons.receipt_long)),
            SizedBox(width: 12),
            Expanded(child: StatCard(title: 'Produk Terjual', value: '342', icon: Icons.shopping_bag)),
          ],
        ),
        const SizedBox(height: 22),
        const Text('Menu Cepat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        const Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            QuickAction(icon: Icons.point_of_sale, title: 'Kasir'),
            QuickAction(icon: Icons.add_box, title: 'Tambah Produk'),
            QuickAction(icon: Icons.inventory, title: 'Stok'),
            QuickAction(icon: Icons.bar_chart, title: 'Laporan'),
          ],
        ),
        const SizedBox(height: 24),
        const Text('Transaksi Terbaru', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        ...[
          ('TRX-00128', 'Rp 125.000', '08:42'),
          ('TRX-00127', 'Rp 340.000', '08:31'),
          ('TRX-00126', 'Rp 89.500', '08:15'),
        ].map((e) => ListTile(
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(child: Icon(Icons.receipt_long)),
          title: Text(e.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(e.$3),
          trailing: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
        )),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 12),
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Text(title, style: const TextStyle(color: Colors.grey)),
      ]),
    ),
  );
}

class QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  const QuickAction({super.key, required this.icon, required this.title});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 150,
    child: Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 10),
          Flexible(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))),
        ]),
      ),
    ),
  );
}

class ProductsPage extends StatelessWidget {
  const ProductsPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Produk', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      TextField(
        decoration: InputDecoration(
          hintText: 'Cari produk...',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 16),
      ...[
        ('Kopi Susu', 'Rp 18.000', 'Stok 42'),
        ('Mie Goreng', 'Rp 15.000', 'Stok 28'),
        ('Air Mineral', 'Rp 5.000', 'Stok 96'),
        ('Teh Manis', 'Rp 7.000', 'Stok 55'),
      ].map((p) => Card(
        elevation: 0,
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.inventory_2)),
          title: Text(p.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(p.$3),
          trailing: Text(p.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      )),
    ],
  );
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Transaksi', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      ...List.generate(8, (i) => Card(
        elevation: 0,
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
          title: Text('TRX-${128-i}', style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('Hari ini • ${8 + (i % 3)}:${10 + i}'),
          trailing: Text('Rp ${(125 + i * 35)}.000', style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      )),
    ],
  );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Pengaturan', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      Card(
        elevation: 0,
        child: Column(children: const [
          ListTile(leading: Icon(Icons.store), title: Text('Profil Toko'), subtitle: Text('Toko Utama')),
          Divider(height: 1),
          ListTile(leading: Icon(Icons.print), title: Text('Printer'), subtitle: Text('Belum terhubung')),
          Divider(height: 1),
          ListTile(leading: Icon(Icons.people), title: Text('Pengguna & Kasir')),
          Divider(height: 1),
          ListTile(leading: Icon(Icons.backup), title: Text('Backup Data')),
        ]),
      ),
    ],
  );
}
