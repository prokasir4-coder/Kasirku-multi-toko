import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('KasirKuPro tampil', (tester) async {
    await tester.pumpWidget(const KasirKuProApp());
    expect(find.text('KasirKuPro'), findsOneWidget);
    expect(find.text('Penjualan Hari Ini'), findsOneWidget);
  });
}
