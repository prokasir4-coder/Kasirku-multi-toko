# KasirKuPro

Aplikasi kasir Flutter modern.

## Fitur awal
- Dashboard penjualan
- Produk
- Transaksi
- Pengaturan toko
- UI Material 3

## Menjalankan
```bash
flutter pub get
flutter run
```
