import 'package:flutter/material.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color brand = Color(0xFF3F56C8);
const Color brandSoft = Color(0xFFE9EDFF);

void main() => runApp(const KasirKuProApp());

class KasirKuProApp extends StatefulWidget {
  const KasirKuProApp({super.key});
  @override
  State<KasirKuProApp> createState() => _KasirKuProAppState();
}

class _KasirKuProAppState extends State<KasirKuProApp> {
  ThemeMode mode = ThemeMode.light;
  String storeName = 'Nama Toko';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      mode = (p.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
      storeName = p.getString('store') ?? 'Nama Toko';
    });
  }

  Future<void> setDark(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', value);
    if (mounted) setState(() => mode = value ? ThemeMode.dark : ThemeMode.light);
  }

  Future<void> setStore(String value) async {
    final name = value.trim().isEmpty ? 'Nama Toko' : value.trim();
    final p = await SharedPreferences.getInstance();
    await p.setString('store', name);
    if (mounted) setState(() => storeName = name);
  }

  ThemeData theme(Brightness b) {
    final scheme = ColorScheme.fromSeed(seedColor: brand, brightness: b);
    return ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: scheme,
      scaffoldBackgroundColor: b == Brightness.dark ? const Color(0xFF0B1020) : const Color(0xFFF6F8FC),
      appBarTheme: AppBarTheme(
        backgroundColor: b == Brightness.dark ? const Color(0xFF0B1020) : const Color(0xFFF6F8FC),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: b == Brightness.dark ? const Color(0xFF151C30) : Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: b == Brightness.dark ? const Color(0xFF151C30) : Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: scheme.primary, width: 1.5)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KasirKuPro',
      theme: theme(Brightness.light),
      darkTheme: theme(Brightness.dark),
      themeMode: mode,
      home: MainShell(storeName: storeName, onDark: setDark, onStore: setStore),
    );
  }
}

class Product {
  Product({required this.name, required this.category, required this.price, required this.stock, this.sku = ''});
  final String name;
  final String category;
  final int price;
  final int stock;
  final String sku;
}

class CartItem {
  CartItem({required this.product, this.qty = 1});
  final Product product;
  int qty;
  int get total => product.price * qty;
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.storeName, required this.onDark, required this.onStore});
  final String storeName;
  final ValueChanged<bool> onDark;
  final ValueChanged<String> onStore;
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final List<Product> products = [];
  final List<String> categories = ['Semua', 'Makanan', 'Minuman', 'Jasa'];

  void go(int value) {
    setState(() => index = value);
    if (Navigator.of(context).canPop()) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final titles = ['Kasir', 'Produk', 'Transaksi', 'Laporan', 'Pengaturan'];
    final pages = [
      CashierPage(products: products, onNeedProduct: () => go(1)),
      ProductsPage(products: products, onChanged: () => setState(() {})),
      const TransactionsPage(),
      const ReportsPage(),
      SettingsPage(storeName: widget.storeName, onDark: widget.onDark, onStore: widget.onStore),
    ];
    return Scaffold(
      drawer: AppDrawer(storeName: widget.storeName, current: index, onSelect: go),
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            tooltip: 'Menu',
            onPressed: () => Scaffold.of(context).openDrawer(),
            icon: const Icon(Icons.menu_rounded),
          ),
        ),
        title: Text(titles[index], style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          if (index == 0)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
            ),
        ],
      ),
      body: SafeArea(child: pages[index]),
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key, required this.storeName, required this.current, required this.onSelect});
  final String storeName;
  final int current;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return NavigationDrawer(
      selectedIndex: current,
      onDestinationSelected: onSelect,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 34, 20, 18),
          child: Row(
            children: [
              CircleAvatar(radius: 28, backgroundColor: brandSoft, child: Icon(Icons.storefront_rounded, color: brand)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(storeName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                Text('POS Professional', style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12)),
              ])),
            ],
          ),
        ),
        const Divider(indent: 18, endIndent: 18),
        const Padding(padding: EdgeInsets.fromLTRB(28, 16, 20, 8), child: Text('OPERASIONAL', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.1))),
        const NavigationDrawerDestination(icon: Icon(Icons.point_of_sale_outlined), selectedIcon: Icon(Icons.point_of_sale_rounded), label: Text('Kasir')),
        const NavigationDrawerDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2_rounded), label: Text('Produk & Stok')),
        const NavigationDrawerDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long_rounded), label: Text('Transaksi')),
        const NavigationDrawerDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart_rounded), label: Text('Laporan')),
        const Padding(padding: EdgeInsets.fromLTRB(28, 16, 20, 8), child: Text('SISTEM', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 1.1))),
        const NavigationDrawerDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: Text('Pengaturan')),
        const Padding(
          padding: EdgeInsets.fromLTRB(28, 20, 28, 16),
          child: Text('Geser atau tap menu untuk membuka dan menutup panel.', style: TextStyle(fontSize: 12)),
        ),
      ],
    );
  }
}

class CashierPage extends StatefulWidget {
  const CashierPage({super.key, required this.products, required this.onNeedProduct});
  final List<Product> products;
  final VoidCallback onNeedProduct;
  @override
  State<CashierPage> createState() => _CashierPageState();
}

class _CashierPageState extends State<CashierPage> {
  final search = TextEditingController();
  String query = '';
  String category = 'Semua';
  final Map<String, CartItem> cart = {};

  List<Product> get filtered => widget.products.where((p) {
    final q = query.toLowerCase();
    final okSearch = q.isEmpty || p.name.toLowerCase().contains(q) || p.sku.toLowerCase().contains(q);
    final okCat = category == 'Semua' || p.category == category;
    return okSearch && okCat;
  }).toList();

  int get total => cart.values.fold(0, (sum, item) => sum + item.total);
  int get count => cart.values.fold(0, (sum, item) => sum + item.qty);

  void add(Product p) {
    setState(() {
      final existing = cart[p.name];
      if (existing == null) cart[p.name] = CartItem(product: p);
      else if (existing.qty < p.stock || p.stock == 0) existing.qty++;
    });
  }

  void remove(Product p) {
    final item = cart[p.name];
    if (item == null) return;
    setState(() {
      if (item.qty <= 1) cart.remove(p.name); else item.qty--;
    });
  }

  Future<void> checkout() async {
    if (cart.isEmpty) return;
    final payment = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => PaymentSheet(total: total),
    );
    if (!mounted || payment == null) return;
    setState(() => cart.clear());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pembayaran $payment berhasil.')));
  }

  @override
  void dispose() { search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: Row(children: [
          Expanded(child: TextField(controller: search, onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Cari nama / SKU...'))),
          const SizedBox(width: 8),
          IconButton.filledTonal(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fitur barcode siap dihubungkan ke kamera.'))), icon: const Icon(Icons.qr_code_scanner_rounded)),
        ]),
      ),
      SizedBox(height: 44, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal, itemBuilder: (_, i) => ChoiceChip(label: Text(['Semua','Makanan','Minuman','Jasa'][i]), selected: category == ['Semua','Makanan','Minuman','Jasa'][i], onSelected: (_) => setState(() => category = ['Semua','Makanan','Minuman','Jasa'][i])), separatorBuilder: (_, __) => const SizedBox(width: 8), itemCount: 4)),
      const SizedBox(height: 8),
      Expanded(
        child: filtered.isEmpty ? Padding(padding: const EdgeInsets.all(16), child: EmptyCard(icon: Icons.point_of_sale_outlined, title: widget.products.isEmpty ? 'Kasir siap digunakan' : 'Produk tidak ditemukan', text: widget.products.isEmpty ? 'Tambahkan produk dulu, lalu pilih produk dari halaman kasir.' : 'Coba kata kunci atau kategori lain.', actionLabel: widget.products.isEmpty ? 'Tambah produk' : null, action: widget.products.isEmpty ? widget.onNeedProduct : null)) : GridView.builder(padding: const EdgeInsets.fromLTRB(16, 8, 16, 110), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .88), itemCount: filtered.length, itemBuilder: (_, i) {
          final p = filtered[i]; final inCart = cart[p.name]?.qty ?? 0;
          return Card(child: InkWell(borderRadius: BorderRadius.circular(20), onTap: () => add(p), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(height: 74, width: double.infinity, decoration: BoxDecoration(color: scheme.primaryContainer, borderRadius: BorderRadius.circular(16)), child: Icon(Icons.inventory_2_rounded, size: 34, color: scheme.primary)),
            const SizedBox(height: 10), Text(p.category, style: TextStyle(fontSize: 11, color: scheme.onSurfaceVariant, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4), Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
            const Spacer(), Row(children: [Expanded(child: Text('Rp ${money(p.price)}', style: const TextStyle(fontWeight: FontWeight.w900))), if (inCart > 0) Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: scheme.primaryContainer, borderRadius: BorderRadius.circular(10)), child: Text('$inCart'))])
          ]))));
        }),
      ),
      if (cart.isNotEmpty) _CartBar(count: count, total: total, onTap: checkout),
    ]);
  }
}

class _CartBar extends StatelessWidget {
  const _CartBar({required this.count, required this.total, required this.onTap});
  final int count; final int total; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(16, 6, 16, 12), child: FilledButton(onPressed: onTap, style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))), child: Row(children: [Text('$count item', style: const TextStyle(fontWeight: FontWeight.w800)), const Spacer(), Text('Rp ${money(total)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)), const SizedBox(width: 10), const Icon(Icons.arrow_forward_rounded)]))));
}

class PaymentSheet extends StatefulWidget {
  const PaymentSheet({super.key, required this.total});
  final int total;
  @override State<PaymentSheet> createState() => _PaymentSheetState();
}
class _PaymentSheetState extends State<PaymentSheet> {
  final amount = TextEditingController();
  String method = 'Tunai';
  @override void dispose(){amount.dispose(); super.dispose();}
  @override Widget build(BuildContext context){
    final paid = int.tryParse(amount.text) ?? 0;
    final change = paid - widget.total;
    return Padding(padding: EdgeInsets.fromLTRB(20, 10, 20, MediaQuery.of(context).viewInsets.bottom + 24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children:[
      const Text('Pembayaran', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), const SizedBox(height: 6),
      Text('Total tagihan Rp ${money(widget.total)}', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)), const SizedBox(height: 16),
      Wrap(spacing: 8, children:['Tunai','QRIS','Transfer','Kartu'].map((m)=>ChoiceChip(label:Text(m), selected:method==m, onSelected:(_)=>setState(()=>method=m))).toList()),
      const SizedBox(height: 14),
      if(method=='Tunai') TextField(controller:amount, keyboardType:TextInputType.number, onChanged:(_)=>setState((){}), decoration: const InputDecoration(labelText:'Uang diterima', prefixText:'Rp ')),
      if(method=='Tunai') Padding(padding:const EdgeInsets.only(top:10), child:Row(children:[const Text('Kembalian',style:TextStyle(fontWeight:FontWeight.w800)), const Spacer(), Text(change<0?'Kurang Rp ${money(-change)}':'Rp ${money(change)}',style:TextStyle(fontWeight:FontWeight.w900))])),
      const SizedBox(height:18),
      FilledButton(onPressed: method!='Tunai'||paid>=widget.total ? ()=>Navigator.pop(context,method):null, style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(54)), child:Text('Selesaikan Pembayaran')),
    ]);
  }
}

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key, required this.products, required this.onChanged});
  final List<Product> products; final VoidCallback onChanged;
  @override State<ProductsPage> createState()=>_ProductsPageState();
}
class _ProductsPageState extends State<ProductsPage>{
  final search=TextEditingController(); String q='';
  Future<void> add() async {
    final n=TextEditingController(), p=TextEditingController(), s=TextEditingController(), sku=TextEditingController(); String cat='Makanan';
    final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,showDragHandle:true,builder:(context)=>StatefulBuilder(builder:(context,setSheet)=>Padding(padding:EdgeInsets.fromLTRB(20,10,20,MediaQuery.of(context).viewInsets.bottom+24),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Produk baru',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:16),
      TextField(controller:n,decoration:const InputDecoration(labelText:'Nama produk',prefixIcon:Icon(Icons.inventory_2_outlined))),const SizedBox(height:10),
      TextField(controller:sku,decoration:const InputDecoration(labelText:'SKU / barcode (opsional)',prefixIcon:Icon(Icons.qr_code_2_rounded))),const SizedBox(height:10),
      DropdownButtonFormField<String>(value:cat,decoration:const InputDecoration(labelText:'Kategori'),items:['Makanan','Minuman','Jasa'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v){if(v!=null)setSheet(()=>cat=v);}),const SizedBox(height:10),
      TextField(controller:p,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Harga jual',prefixText:'Rp ')),const SizedBox(height:10),
      TextField(controller:s,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stok awal')),const SizedBox(height:18),
      FilledButton(onPressed:(){final name=n.text.trim();final price=int.tryParse(p.text)??0;final stock=int.tryParse(s.text)??0;if(name.isEmpty||price<=0)return;widget.products.add(Product(name:name,category:cat,price:price,stock:stock,sku:sku.text.trim()));Navigator.pop(context,true);},style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(54)),child:const Text('Simpan produk'))
    ])))););
    if(ok==true&&mounted){setState((){});widget.onChanged();}
  }
  @override Widget build(BuildContext context){final list=widget.products.where((p)=>p.name.toLowerCase().contains(q.toLowerCase())||p.sku.toLowerCase().contains(q.toLowerCase())).toList(); return ListView(padding:const EdgeInsets.all(16),children:[
    Row(children:[const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Produk & Stok',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),SizedBox(height:4),Text('Kontrol harga, SKU, kategori, dan stok.')])) ,FilledButton.icon(onPressed:add,icon:const Icon(Icons.add_rounded),label:const Text('Tambah'))]),const SizedBox(height:16),TextField(controller:search,onChanged:(v)=>setState(()=>q=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search_rounded),hintText:'Cari produk / SKU...')),const SizedBox(height:12),
    if(list.isEmpty) const EmptyCard(icon:Icons.inventory_2_outlined,title:'Belum ada produk',text:'Tambahkan produk untuk mengaktifkan kasir.',actionLabel:'Tambah produk',action:null) else ...list.map((p)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:brandSoft,child:const Icon(Icons.inventory_2_rounded,color:brand)),title:Text(p.name,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('${p.category} • Stok ${p.stock}${p.sku.isEmpty?'':' • ${p.sku}'}'),trailing:Text('Rp ${money(p.price)}',style:const TextStyle(fontWeight:FontWeight.w900)))))
  ];}
}

class TransactionsPage extends StatelessWidget { const TransactionsPage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Transaksi',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:4),const Text('Cari, cek detail, dan cetak ulang nota.'),const SizedBox(height:18),Row(children:[Expanded(child: _MiniFilter(icon:Icons.calendar_today_rounded,label:'Hari ini')),const SizedBox(width:8),Expanded(child:_MiniFilter(icon:Icons.filter_list_rounded,label:'Semua metode'))]),const SizedBox(height:18),const EmptyCard(icon:Icons.receipt_long_outlined,title:'Belum ada transaksi',text:'Riwayat penjualan akan tampil di sini setelah kasir digunakan.')]); }
}
class _MiniFilter extends StatelessWidget{const _MiniFilter({required this.icon,required this.label});final IconData icon;final String label;@override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.symmetric(horizontal:14,vertical:12),child:Row(children:[Icon(icon,size:18,color:Theme.of(context).colorScheme.primary),const SizedBox(width:8),Expanded(child:Text(label,style:const TextStyle(fontWeight:FontWeight.w800))),const Icon(Icons.expand_more_rounded,size:18)])));}

class ReportsPage extends StatelessWidget { const ReportsPage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Laporan',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:4),const Text('Ringkasan performa toko untuk mengambil keputusan.'),const SizedBox(height:18),Row(children:[Expanded(child:MetricCard(label:'Omzet hari ini',value:'Rp 0',icon:Icons.payments_rounded)),const SizedBox(width:10),Expanded(child:MetricCard(label:'Transaksi',value:'0',icon:Icons.receipt_long_rounded))]),const SizedBox(height:12),Row(children:[Expanded(child:MetricCard(label:'Laba kotor',value:'Rp 0',icon:Icons.trending_up_rounded)),const SizedBox(width:10),Expanded(child:MetricCard(label:'Produk terjual',value:'0',icon:Icons.shopping_bag_rounded))]),const SizedBox(height:18),Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Tren penjualan',style:TextStyle(fontWeight:FontWeight.w900,fontSize:18)),const SizedBox(height:8),SizedBox(height:160,child:Center(child:Icon(Icons.show_chart_rounded,size:58))),const Center(child:Text('Grafik akan aktif setelah ada transaksi.'))])))]);}
class MetricCard extends StatelessWidget{const MetricCard({super.key,required this.label,required this.value,required this.icon});final String label,value;final IconData icon;@override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:Theme.of(context).colorScheme.primary),const SizedBox(height:12),Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:2),Text(label,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant))])));}

class SettingsPage extends StatefulWidget { const SettingsPage({super.key,required this.storeName,required this.onDark,required this.onStore}); final String storeName; final ValueChanged<bool> onDark; final ValueChanged<String> onStore; @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{
  bool low=true,sound=true,autoPrint=false; String paper='58 mm', printer='Belum terhubung', mac='';
  Future<void> editStore() async {final c=TextEditingController(text:widget.storeName);final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,showDragHandle:true,builder:(context)=>Padding(padding:EdgeInsets.fromLTRB(20,10,20,MediaQuery.of(context).viewInsets.bottom+24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Align(alignment:Alignment.centerLeft,child:Text('Profil toko',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900))),const SizedBox(height:16),TextField(controller:c,decoration:const InputDecoration(labelText:'Nama toko',prefixIcon:Icon(Icons.storefront_outlined))),const SizedBox(height:16),FilledButton(onPressed:()=>Navigator.pop(context,true),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(52)),child:const Text('Simpan'))])));if(ok==true)widget.onStore(c.text);}
  Future<void> printers() async {try{final paired=await PrintBluetoothThermal.pairedBluetooths;if(!mounted)return;await showModalBottomSheet(context:context,isScrollControlled:true,showDragHandle:true,builder:(context)=>SizedBox(height:MediaQuery.of(context).size.height*.72,child:ListView(padding:const EdgeInsets.all(16),children:[const Text('Cari perangkat printer',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Printer Bluetooth harus sudah dipasangkan di Pengaturan Bluetooth HP.'),const SizedBox(height:14),if(paired.isEmpty)const EmptyCard(icon:Icons.print_disabled_rounded,title:'Tidak ada printer ditemukan',text:'Pasangkan printer thermal 58/80 mm melalui Bluetooth HP lalu coba lagi.') else ...paired.map((d)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:brandSoft,child:const Icon(Icons.print_rounded,color:brand)),title:Text(d.name.isEmpty?'Printer Bluetooth':d.name,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(d.macAdress??'-'),trailing:FilledButton(onPressed:()async{final m=d.macAdress;if(m==null||m.isEmpty)return;final ok=await PrintBluetoothThermal.connect(macPrinterAddress:m);if(!mounted)return;setState((){printer=d.name.isEmpty?'Printer Bluetooth':d.name;mac=m;});Navigator.pop(context);ScaffoldMessenger.of(this.context).showSnackBar(SnackBar(content:Text(ok?'Printer terhubung':'Gagal menghubungkan printer')));},child:const Text('Hubungkan')))))])));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Tidak bisa membaca printer: $e')));}}
  Future<void> testPrint() async {try{final ok=await PrintBluetoothThermal.connectionStatus;if(!ok){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Hubungkan printer terlebih dahulu.')));return;}final result=await PrintBluetoothThermal.writeString(printText:PrintTextSize(size:1,text:'\nKASIRKUPRO\nPrinter Test\n$printer\n${DateTime.now()}\n\n'));if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(result?'Tes cetak berhasil':'Tes cetak gagal')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Tes cetak gagal: $e')));}}
  @override Widget build(BuildContext context){return ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:Padding(padding:const EdgeInsets.all(18),child:Row(children:[CircleAvatar(radius:28,backgroundColor:brandSoft,child:const Icon(Icons.storefront_rounded,color:brand)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(widget.storeName,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:3),const Text('Kelola identitas dan perangkat operasional toko.')])) ,IconButton(onPressed:editStore,icon:const Icon(Icons.edit_rounded))]))),
    const SizedBox(height:18), const SectionLabel('TOKO'),
    SettingTile(icon:Icons.store_outlined,title:'Profil toko',subtitle:'Nama toko dan informasi usaha',onTap:editStore),
    SettingTile(icon:Icons.payments_outlined,title:'Metode pembayaran',subtitle:'Tunai, QRIS, transfer, kartu',onTap:()=>showInfo(context,'Metode pembayaran','Atur metode pembayaran yang akan tampil saat checkout.')),
    const SectionLabel('PRINTER & STRUK'),
    SettingTile(icon:Icons.print_outlined,title:'Printer & Struk',subtitle:printer=='Belum terhubung'?'Belum terhubung • Cari printer Bluetooth':'$printer • $paper',onTap:printers,trailing:const Icon(Icons.chevron_right_rounded)),
    SettingTile(icon:Icons.receipt_long_outlined,title:'Cetak tes',subtitle:'Pastikan format struk siap sebelum jualan',onTap:testPrint),
    SettingSwitch(icon:Icons.autorenew_rounded,title:'Cetak otomatis',subtitle:'Cetak nota setelah pembayaran berhasil',value:autoPrint,onChanged:(v)=>setState(()=>autoPrint=v)),
    ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:6),leading:const CircleAvatar(backgroundColor:brandSoft,child:Icon(Icons.straighten_rounded,color:brand)),title:const Text('Ukuran kertas',style:TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(paper),trailing:DropdownButton<String>(value:paper,items:const [DropdownMenuItem(value:'58 mm',child:Text('58 mm')),DropdownMenuItem(value:'80 mm',child:Text('80 mm'))],onChanged:(v){if(v!=null)setState(()=>paper=v);}),),
    const SectionLabel('PENJUALAN'),
    SettingSwitch(icon:Icons.inventory_2_outlined,title:'Peringatan stok menipis',subtitle:'Tampilkan peringatan saat stok di bawah batas minimum',value:low,onChanged:(v)=>setState(()=>low=v)),
    SettingSwitch(icon:Icons.volume_up_outlined,title:'Suara kasir',subtitle:'Bunyi saat produk ditambahkan ke keranjang',value:sound,onChanged:(v)=>setState(()=>sound=v)),
    const SectionLabel('SISTEM'),
    SettingTile(icon:Icons.backup_outlined,title:'Backup & Pulihkan',subtitle:'Simpan data toko secara berkala',onTap:()=>showInfo(context,'Backup & Pulihkan','Menu backup dapat dihubungkan ke penyimpanan cloud lokal setelah modul data ditambahkan.')),
    SettingTile(icon:Icons.security_outlined,title:'Keamanan & PIN kasir',subtitle:'Kunci transaksi dan akses pengaturan',onTap:()=>showInfo(context,'Keamanan','Aktifkan PIN kasir dan pembatasan akses untuk menjaga transaksi.')),
    SettingSwitch(icon:Icons.dark_mode_outlined,title:'Mode gelap',subtitle:'Gunakan tampilan gelap untuk operasional malam',value:Theme.of(context).brightness==Brightness.dark,onChanged:widget.onDark),
    const SizedBox(height:18), const Center(child:Text('KasirKuPro Professional POS • 2.1.0',style:TextStyle(fontSize:12))),
  ];}
}
class SectionLabel extends StatelessWidget{const SectionLabel(this.text,{super.key});final String text;@override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(4,16,4,8),child:Text(text,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant,fontSize:11,fontWeight:FontWeight.w900,letterSpacing:1.2)));}
class SettingTile extends StatelessWidget{const SettingTile({super.key,required this.icon,required this.title,required this.subtitle,required this.onTap,this.trailing});final IconData icon;final String title,subtitle;final VoidCallback onTap;final Widget? trailing;@override Widget build(BuildContext context)=>Card(child:ListTile(onTap:onTap,contentPadding:const EdgeInsets.symmetric(horizontal:8,vertical:4),leading:CircleAvatar(backgroundColor:brandSoft,child:Icon(icon,color:brand)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(subtitle),trailing:trailing??const Icon(Icons.chevron_right_rounded)));}
class SettingSwitch extends StatelessWidget{const SettingSwitch({super.key,required this.icon,required this.title,required this.subtitle,required this.value,required this.onChanged});final IconData icon;final String title,subtitle;final bool value;final ValueChanged<bool> onChanged;@override Widget build(BuildContext context)=>Card(child:SwitchListTile(value:value,onChanged:onChanged,contentPadding:const EdgeInsets.symmetric(horizontal:8,vertical:4),secondary:CircleAvatar(backgroundColor:brandSoft,child:Icon(icon,color:brand)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text(subtitle)));}

void showInfo(BuildContext context,String title,String text)=>showDialog<void>(context:context,builder:(context)=>AlertDialog(title:Text(title),content:Text(text),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Tutup'))]));
class EmptyCard extends StatelessWidget{const EmptyCard({super.key,required this.icon,required this.title,required this.text,this.actionLabel,this.action});final IconData icon;final String title,text;final String? actionLabel;final VoidCallback? action;@override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(28),child:Column(children:[Icon(icon,size:48,color:Theme.of(context).colorScheme.onSurfaceVariant),const SizedBox(height:12),Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900),textAlign:TextAlign.center),const SizedBox(height:6),Text(text,textAlign:TextAlign.center,style:TextStyle(color:Theme.of(context).colorScheme.onSurfaceVariant)),if(actionLabel!=null&&action!=null)...[const SizedBox(height:14),FilledButton.tonalIcon(onPressed:action,icon:const Icon(Icons.add_rounded),label:Text(actionLabel!))]])));
String money(int v)=>v.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'),(_)=>'.');
