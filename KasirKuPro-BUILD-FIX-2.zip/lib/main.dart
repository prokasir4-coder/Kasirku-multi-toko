import 'package:flutter/material.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _seed = Color(0xFF3156D3);

void main() => runApp(const KasirKuProApp());

class KasirKuProApp extends StatefulWidget {
  const KasirKuProApp({super.key});
  @override State<KasirKuProApp> createState() => _KasirKuProAppState();
}

class _KasirKuProAppState extends State<KasirKuProApp> {
  ThemeMode mode = ThemeMode.light;
  String storeName = 'Nama Toko';

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      mode = (p.getBool('dark') ?? false) ? ThemeMode.dark : ThemeMode.light;
      storeName = p.getString('store') ?? 'Nama Toko';
    });
  }
  Future<void> setDark(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('dark', value);
    setState(() => mode = value ? ThemeMode.dark : ThemeMode.light);
  }
  Future<void> setStore(String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('store', value);
    setState(() => storeName = value.isEmpty ? 'Nama Toko' : value);
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'KasirKuPro',
    themeMode: mode,
    theme: _theme(Brightness.light),
    darkTheme: _theme(Brightness.dark),
    home: Home(storeName: storeName, onDark: setDark, onStore: setStore),
  );

  ThemeData _theme(Brightness b) {
    final dark = b == Brightness.dark;
    final scheme = ColorScheme.fromSeed(seedColor: _seed, brightness: b);
    return ThemeData(
      useMaterial3: true, colorScheme: scheme, brightness: b,
      scaffoldBackgroundColor: dark ? const Color(0xFF0B1020) : const Color(0xFFF6F8FC),
      cardTheme: CardThemeData(elevation: 0, color: dark ? const Color(0xFF151C30) : Colors.white,
        surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: dark ? const Color(0xFF151C30) : Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: scheme.primary, width: 1.5)),
      ),
      navigationBarTheme: NavigationBarThemeData(height: 74, backgroundColor: dark ? const Color(0xFF101629) : Colors.white,
        indicatorColor: scheme.primaryContainer, labelTextStyle: const WidgetStatePropertyAll(TextStyle(fontWeight: FontWeight.w700, fontSize: 12))),
    );
  }
}

class Home extends StatefulWidget {
  final String storeName; final ValueChanged<bool> onDark; final ValueChanged<String> onStore;
  const Home({super.key, required this.storeName, required this.onDark, required this.onStore});
  @override State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  int index = 0;
  final products = <Product>[];
  @override Widget build(BuildContext context) {
    final pages = [
      Dashboard(storeName: widget.storeName, productCount: products.length, onAddProduct: () => setState(() => index = 1)),
      Products(products: products, onChanged: () => setState(() {})),
      const Transactions(),
      Settings(storeName: widget.storeName, onStore: widget.onStore, onDark: widget.onDark),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.grid_view_rounded), selectedIcon: Icon(Icons.grid_view_rounded), label: 'Beranda'),
        NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2_rounded), label: 'Produk'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long_rounded), label: 'Transaksi'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings_rounded), label: 'Pengaturan'),
      ]),
    );
  }
}

class Product { String name; String category; int price; int stock; Product(this.name, this.category, this.price, this.stock); }

class Dashboard extends StatelessWidget {
  final String storeName; final int productCount; final VoidCallback onAddProduct;
  const Dashboard({super.key, required this.storeName, required this.productCount, required this.onAddProduct});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(18,18,18,28), children: [
    Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Selamat datang', style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant, fontWeight: FontWeight.w600)),
      Text(storeName, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
    ])), IconButton.filledTonal(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded))]),
    const SizedBox(height: 18),
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: LinearGradient(colors: [Theme.of(context).colorScheme.primary, Theme.of(context).colorScheme.primary.withValues(alpha:.78)]), borderRadius: BorderRadius.circular(24)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('Penjualan hari ini', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)), SizedBox(height:8), Text('Rp 0', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)), SizedBox(height:6), Text('Belum ada transaksi hari ini', style: TextStyle(color: Colors.white70)),
    ])),
    const SizedBox(height: 14),
    Row(children: [Expanded(child: _Kpi('Transaksi','0',Icons.receipt_long_rounded)), const SizedBox(width:10), Expanded(child: _Kpi('Produk','$productCount',Icons.inventory_2_rounded))]),
    const SizedBox(height: 22),
    Row(children: [const Expanded(child: Text('Aksi cepat', style: TextStyle(fontSize:18,fontWeight:FontWeight.w900))), TextButton.icon(onPressed:onAddProduct, icon:const Icon(Icons.add_rounded), label:const Text('Tambah produk'))]),
    const SizedBox(height: 8),
    Card(child: ListTile(leading: CircleAvatar(backgroundColor: Theme.of(context).colorScheme.primaryContainer, child: Icon(Icons.point_of_sale_rounded, color: Theme.of(context).colorScheme.primary)), title: const Text('Mulai transaksi', style: TextStyle(fontWeight:FontWeight.w800)), subtitle: const Text('Kasir siap digunakan setelah produk ditambahkan'), trailing: const Icon(Icons.chevron_right_rounded))),
    const SizedBox(height: 22),
    const _EmptyCard(icon: Icons.receipt_long_outlined, title: 'Belum ada transaksi', text: 'Transaksi penjualan akan muncul di sini setelah kasir digunakan.'),
  ]);
}
class _Kpi extends StatelessWidget { final String title,value; final IconData icon; const _Kpi(this.title,this.value,this.icon); @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:Theme.of(c).colorScheme.primary),const SizedBox(height:12),Text(value,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),Text(title,style:TextStyle(color:Theme.of(c).colorScheme.onSurfaceVariant))]))); }
class _EmptyCard extends StatelessWidget { final IconData icon; final String title,text; const _EmptyCard({required this.icon,required this.title,required this.text}); @override Widget build(BuildContext c)=>Card(child:Padding(padding:const EdgeInsets.all(28),child:Column(children:[Icon(icon,size:44,color:Theme.of(c).colorScheme.onSurfaceVariant),const SizedBox(height:10),Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:16)),const SizedBox(height:4),Text(text,textAlign:TextAlign.center,style:TextStyle(color:Theme.of(c).colorScheme.onSurfaceVariant))]))); }

class Products extends StatefulWidget { final List<Product> products; final VoidCallback onChanged; const Products({super.key,required this.products,required this.onChanged}); @override State<Products> createState()=>_ProductsState(); }
class _ProductsState extends State<Products> {
  final search=TextEditingController();
  Future<void> add() async { final name=TextEditingController(), price=TextEditingController(), stock=TextEditingController(); String cat='Umum';
    final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,showDragHandle:true,builder:(s)=>StatefulBuilder(builder:(s,set)=>Padding(padding:EdgeInsets.fromLTRB(20,8,20,MediaQuery.of(s).viewInsets.bottom+24),child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Tambah Produk',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:16),TextField(controller:name,decoration:const InputDecoration(labelText:'Nama produk')),const SizedBox(height:10),DropdownButtonFormField<String>(value:cat,decoration:const InputDecoration(labelText:'Kategori'),items:['Umum','Makanan','Minuman','Jasa'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>set(()=>cat=v??'Umum')),const SizedBox(height:10),TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Harga')),const SizedBox(height:10),TextField(controller:stock,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Stok awal')),const SizedBox(height:18),FilledButton(onPressed:()=>Navigator.pop(s,true),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(52)),child:const Text('Simpan Produk'))]))));
    if(ok==true && name.text.trim().isNotEmpty){ widget.products.add(Product(name.text.trim(),cat,int.tryParse(price.text.replaceAll('.',''))??0,int.tryParse(stock.text)??0)); widget.onChanged(); setState((){}); }
  }
  @override Widget build(BuildContext c){ final q=search.text.toLowerCase(); final list=widget.products.where((p)=>p.name.toLowerCase().contains(q)).toList(); return Scaffold(body:ListView(padding:const EdgeInsets.fromLTRB(18,18,18,24),children:[Row(children:[const Expanded(child:Text('Produk',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900))),FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('Tambah'))]),const SizedBox(height:4),Text('Kelola produk dan stok tanpa data demo.',style:TextStyle(color:Theme.of(c).colorScheme.onSurfaceVariant)),const SizedBox(height:18),TextField(controller:search,onChanged:(_)=>setState((){}),decoration:const InputDecoration(prefixIcon:Icon(Icons.search_rounded),hintText:'Cari produk...')),const SizedBox(height:14),if(list.isEmpty) const _EmptyCard(icon:Icons.inventory_2_outlined,title:'Belum ada produk',text:'Tambahkan produk pertama untuk mulai menggunakan kasir.') else ...list.map((p)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:Theme.of(c).colorScheme.primaryContainer,child:Icon(Icons.inventory_2_rounded,color:Theme.of(c).colorScheme.primary)),title:Text(p.name,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:Text('${p.category} • Stok ${p.stock}'),trailing:Text('Rp ${_money(p.price)}',style:const TextStyle(fontWeight:FontWeight.w900)))))])); }
}

class Transactions extends StatelessWidget { const Transactions({super.key}); @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.fromLTRB(18,18,18,24),children:[const Text('Transaksi',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text('Riwayat penjualan tersimpan di sini.',style:TextStyle(color:Colors.grey)),const SizedBox(height:18),const _EmptyCard(icon:Icons.receipt_long_outlined,title:'Belum ada transaksi',text:'Setelah penjualan pertama, detail transaksi akan tampil di halaman ini.')]); }

class Settings extends StatefulWidget { final String storeName; final ValueChanged<String> onStore; final ValueChanged<bool> onDark; const Settings({super.key,required this.storeName,required this.onStore,required this.onDark}); @override State<Settings> createState()=>_SettingsState(); }
class _SettingsState extends State<Settings>{ bool dark=false,autoPrint=true,lowStock=true,sound=true; String printer='Belum terhubung'; String paper='58 mm';
  @override void initState(){super.initState(); _load();} Future<void> _load() async{final p=await SharedPreferences.getInstance(); setState(()=>dark=p.getBool('dark')??false);}
  void info(String title,String text)=>showDialog(context:context,builder:(d)=>AlertDialog(title:Text(title),content:Text(text),actions:[TextButton(onPressed:()=>Navigator.pop(d),child:const Text('Tutup'))]));
  Future<void> profile() async{final ctl=TextEditingController(text:widget.storeName); final ok=await showModalBottomSheet<bool>(context:context,isScrollControlled:true,showDragHandle:true,builder:(s)=>Padding(padding:EdgeInsets.fromLTRB(20,8,20,MediaQuery.of(s).viewInsets.bottom+24),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Profil Toko',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900)),const SizedBox(height:16),TextField(controller:ctl,decoration:const InputDecoration(labelText:'Nama toko',prefixIcon:Icon(Icons.storefront_outlined))),const SizedBox(height:16),FilledButton(onPressed:()=>Navigator.pop(s,true),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(52)),child:const Text('Simpan'))])); if(ok==true){await widget.onStore(ctl.text.trim());setState((){});}}
  Widget tile({required IconData icon,required String title,String? sub,VoidCallback? tap,Widget? trailing})=>ListTile(onTap:tap,contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:4),leading:CircleAvatar(backgroundColor:Theme.of(context).colorScheme.surfaceContainerHighest,child:Icon(icon,color:Theme.of(context).colorScheme.primary)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),subtitle:sub==null?null:Text(sub),trailing:trailing??(tap==null?null:const Icon(Icons.chevron_right_rounded)));
  Widget card(List<Widget> x)=>Card(clipBehavior:Clip.antiAlias,margin:EdgeInsets.zero,child:Column(children:x));
  @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.fromLTRB(18,18,18,28),children:[Row(children:[const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Pengaturan',style:TextStyle(fontSize:29,fontWeight:FontWeight.w900)),SizedBox(height:4),Text('Kelola toko, kasir, transaksi, dan sistem.')])) ,IconButton.filledTonal(onPressed:profile,icon:const Icon(Icons.edit_rounded))]),const SizedBox(height:18),Card(child:ListTile(onTap:profile,contentPadding:const EdgeInsets.all(14),leading:CircleAvatar(radius:28,child:Icon(Icons.storefront_rounded)),title:Text(widget.storeName,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),subtitle:const Text('Profil toko siap diatur'),trailing:const Icon(Icons.chevron_right_rounded))),_section('Perangkat','Printer dan perangkat kasir.'),card([tile(icon:Icons.print_rounded,title:'Printer & Struk',sub:'$printer • $paper • ${autoPrint?'Otomatis':'Manual'}',tap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PrinterSettings(initialPrinter:printer,initialPaper:paper,initialAuto:autoPrint,onSaved:(p,w,a)=>setState((){printer=p;paper=w;autoPrint=a;})))),const Divider(height:1),tile(icon:Icons.payments_outlined,title:'Metode Pembayaran',sub:'Tunai • QRIS • Transfer • Kartu',tap:()=>info('Metode Pembayaran','Aktifkan metode pembayaran yang tersedia di kasir.')),]),_section('Penjualan','Aturan harga dan operasional.'),card([tile(icon:Icons.percent_rounded,title:'Pajak & Diskon',sub:'Atur pajak dan diskon saat transaksi',tap:()=>info('Pajak & Diskon','Pengaturan pajak dan diskon siap digunakan pada modul kasir.')),const Divider(height:1),tile(icon:Icons.notifications_active_outlined,title:'Peringatan Stok',sub:lowStock?'Notifikasi stok menipis aktif':'Notifikasi stok menipis nonaktif',trailing:Switch.adaptive(value:lowStock,onChanged:(v)=>setState(()=>lowStock=v))),const Divider(height:1),tile(icon:Icons.volume_up_outlined,title:'Suara Kasir',sub:sound?'Suara aktif':'Suara nonaktif',trailing:Switch.adaptive(value:sound,onChanged:(v)=>setState(()=>sound=v)))]),_section('Tampilan & Data','Personalisasi dan keamanan data.'),card([tile(icon:Icons.dark_mode_outlined,title:'Mode Gelap',sub:dark?'Aktif':'Terang',trailing:Switch.adaptive(value:dark,onChanged:(v){setState(()=>dark=v);widget.onDark(v);})),const Divider(height:1),tile(icon:Icons.badge_outlined,title:'Pengguna & Kasir',sub:'Atur akses pemilik dan kasir',tap:()=>info('Pengguna & Kasir','Tambahkan akun kasir dan hak akses sesuai kebutuhan toko.')),const Divider(height:1),tile(icon:Icons.backup_outlined,title:'Backup & Pulihkan',sub:'Cadangkan data aplikasi',tap:()=>info('Backup & Pulihkan','Fitur backup dapat digunakan untuk menjaga data toko.'))]),_section('Aplikasi','Informasi aplikasi.'),card([tile(icon:Icons.help_outline_rounded,title:'Bantuan',sub:'Panduan penggunaan KasirKuPro',tap:()=>info('Bantuan','Hubungkan printer Bluetooth, pilih printer, lalu tekan Cetak Tes.')),const Divider(height:1),tile(icon:Icons.info_outline_rounded,title:'Tentang',sub:'KasirKuPro Professional POS • 2.0.0',tap:()=>info('KasirKuPro','POS modern tanpa data demo.'))])]);
}
Widget _section(String a,String b)=>Builder(builder:(c)=>Padding(padding:const EdgeInsets.fromLTRB(4,20,4,10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),const SizedBox(height:3),Text(b,style:TextStyle(fontSize:13,color:Theme.of(c).colorScheme.onSurfaceVariant))]));

class PrinterSettings extends StatefulWidget {
  final String initialPrinter;
  final String initialPaper;
  final bool initialAuto;
  final void Function(String, String, bool) onSaved;

  const PrinterSettings({
    super.key,
    required this.initialPrinter,
    required this.initialPaper,
    required this.initialAuto,
    required this.onSaved,
  });

  @override
  State<PrinterSettings> createState() => _PrinterSettingsState();
}

class _PrinterSettingsState extends State<PrinterSettings> {
  List<BluetoothInfo> devices = <BluetoothInfo>[];
  bool loading = false;
  bool auto = true;
  bool connected = false;
  String? selected;
  String paper = '58 mm';

  @override
  void initState() {
    super.initState();
    auto = widget.initialAuto;
    paper = widget.initialPaper;
    selected = widget.initialPrinter == 'Belum terhubung'
        ? null
        : widget.initialPrinter;
    _status();
    _scan();
  }

  Future<void> _status() async {
    try {
      final bool value = await PrintBluetoothThermal.connectionStatus;
      if (mounted) {
        setState(() => connected = value);
      }
    } catch (_) {}
  }

  Future<void> _scan() async {
    if (mounted) setState(() => loading = true);
    try {
      final bool permission =
          await PrintBluetoothThermal.isPermissionBluetoothGranted;
      final bool enabled = await PrintBluetoothThermal.bluetoothEnabled;

      if (!permission) {
        _message(
          'Izin Bluetooth belum diberikan. Izinkan akses Perangkat Terdekat di Android.',
        );
        return;
      }
      if (!enabled) {
        _message('Bluetooth sedang mati. Nyalakan Bluetooth lalu cari lagi.');
        return;
      }

      final List<BluetoothInfo> result =
          await PrintBluetoothThermal.pairedBluetooths;
      if (mounted) {
        setState(() => devices = result);
      }
    } catch (e) {
      _message('Tidak dapat membaca perangkat Bluetooth: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _connect(BluetoothInfo device) async {
    final String? mac = device.macAdress;
    if (mac == null || mac.isEmpty) {
      _message('Alamat Bluetooth printer tidak tersedia.');
      return;
    }

    try {
      final bool ok = await PrintBluetoothThermal.connect(
        macPrinterAddress: mac,
      );
      if (!mounted) return;

      if (ok) {
        final String label =
            device.name.trim().isEmpty ? mac : device.name.trim();
        setState(() {
          connected = true;
          selected = label;
        });
        widget.onSaved(label, paper, auto);
        _message('Printer berhasil terhubung.');
      } else {
        _message(
          'Gagal terhubung. Pastikan printer sudah dipasangkan di Bluetooth HP.',
        );
      }
    } catch (e) {
      _message('Gagal terhubung: $e');
    }
  }

  Future<void> _testPrint() async {
    try {
      final bool status = await PrintBluetoothThermal.connectionStatus;
      if (!status) {
        _message('Hubungkan printer terlebih dahulu.');
        return;
      }

      final bool first = await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(
          size: 2,
          text: 'KASIRKUPRO\n',
        ),
      );
      final bool second = await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(
          size: 1,
          text: 'Tes printer berhasil\n$paper\n\n',
        ),
      );

      _message(first && second
          ? 'Cetak tes berhasil.'
          : 'Cetak tes gagal.');
    } catch (e) {
      _message('Cetak tes gagal: $e');
    }
  }

  void _message(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Widget _deviceTile(BuildContext context, BluetoothInfo device) {
    final String? mac = device.macAdress;
    final String label =
        device.name.trim().isEmpty ? 'Printer Bluetooth' : device.name.trim();
    final bool isSelected = selected == label;

    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).colorScheme.primaryContainer,
          child: Icon(
            Icons.print_rounded,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
        title: Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text(mac ?? 'Alamat Bluetooth tidak tersedia'),
        trailing: FilledButton(
          onPressed: mac == null || mac.isEmpty ? null : () => _connect(device),
          child: Text(isSelected && connected ? 'Terhubung' : 'Pilih'),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Printer & Struk',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
        children: <Widget>[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: Theme.of(context)
                              .colorScheme
                              .primaryContainer,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Icon(
                          Icons.print_rounded,
                          color: Theme.of(context).colorScheme.primary,
                          size: 28,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              connected ? 'Printer terhubung' : 'Belum terhubung',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            Text(
                              selected ?? 'Pilih printer thermal Bluetooth',
                              style: TextStyle(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: loading ? null : _scan,
                    icon: loading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.bluetooth_searching_rounded),
                    label: Text(
                      loading ? 'Mencari...' : 'Cari perangkat printer',
                    ),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                    ),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: connected ? _testPrint : null,
                    icon: const Icon(Icons.receipt_long_rounded),
                    label: const Text('Cetak tes'),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Perangkat Bluetooth yang sudah dipasangkan',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          if (devices.isEmpty)
            const _EmptyCard(
              icon: Icons.bluetooth_disabled_rounded,
              title: 'Belum ada perangkat',
              text:
                  'Pasangkan printer di Pengaturan Bluetooth HP, lalu tekan Cari perangkat.',
            )
          else
            ...devices.map((device) => _deviceTile(context, device)),
          const SizedBox(height: 18),
          Card(
            child: Column(
              children: <Widget>[
                ListTile(
                  title: const Text(
                    'Cetak otomatis',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: const Text(
                    'Cetak struk setelah transaksi selesai',
                  ),
                  trailing: Switch.adaptive(
                    value: auto,
                    onChanged: (bool value) {
                      setState(() => auto = value);
                      widget.onSaved(
                        selected ?? 'Belum terhubung',
                        paper,
                        auto,
                      );
                    },
                  ),
                ),
                const Divider(height: 1),
                ListTile(
                  title: const Text(
                    'Ukuran kertas',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text('Thermal $paper'),
                  trailing: DropdownButton<String>(
                    value: paper,
                    items: <String>['58 mm', '80 mm']
                        .map(
                          (String value) => DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          ),
                        )
                        .toList(),
                    onChanged: (String? value) {
                      if (value == null) return;
                      setState(() => paper = value);
                      widget.onSaved(
                        selected ?? 'Belum terhubung',
                        paper,
                        auto,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String _money(int n)=>n.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'),(_)=>'.');
