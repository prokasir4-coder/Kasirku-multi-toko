import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('KasirKuPro renders professional cashier shell', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: CashierPage(
          products: <Product>[],
          taxPercent: 0,
          autoPrint: false,
          printerName: 'Belum terhubung',
          printerMac: '',
          paper: '58 mm',
          storeName: 'Demo Toko',
          storeAddress: '',
          storePhone: '',
          onNeedProduct: () {},
          onCompleteSale: (_) async {},
        ),
      ),
    );
    await tester.pump();
    expect(find.text('Kasir siap digunakan'), findsOneWidget);
    expect(find.text('Cari produk / SKU...'), findsOneWidget);
  });
}
