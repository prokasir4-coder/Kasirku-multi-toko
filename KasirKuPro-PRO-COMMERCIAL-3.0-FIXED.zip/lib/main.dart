import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color brand = Color(0xFF3F56C8);
const Color brandSoft = Color(0xFFE9EDFF);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KasirKuProApp());
}

class KasirKuProApp extends StatefulWidget {
  const KasirKuProApp({super.key});

  @override
  State<KasirKuProApp> createState() => _KasirKuProAppState();
}

class _KasirKuProAppState extends State<KasirKuProApp> {
  ThemeMode _themeMode = ThemeMode.light;
  String _storeName = 'Nama Toko';

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _themeMode = (prefs.getBool('dark_mode') ?? false)
          ? ThemeMode.dark
          : ThemeMode.light;
      _storeName = prefs.getString('store_name') ?? 'Nama Toko';
    });
  }

  Future<void> _setDarkMode(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('dark_mode', value);
    if (!mounted) return;
    setState(() {
      _themeMode = value ? ThemeMode.dark : ThemeMode.light;
    });
  }

  Future<void> _setStoreName(String value) async {
    final name = value.trim().isEmpty ? 'Nama Toko' : value.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('store_name', name);
    if (!mounted) return;
    setState(() => _storeName = name);
  }

  ThemeData _buildTheme(Brightness brightness) {
    final scheme = ColorScheme.fromSeed(
      seedColor: brand,
      brightness: brightness,
    );
    final dark = brightness == Brightness.dark;
    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor:
          dark ? const Color(0xFF0B1020) : const Color(0xFFF6F8FC),
      appBarTheme: AppBarTheme(
        backgroundColor:
            dark ? const Color(0xFF0B1020) : const Color(0xFFF6F8FC),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: dark ? const Color(0xFF151C30) : Colors.white,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: dark ? const Color(0xFF151C30) : Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: scheme.primary, width: 1.5),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KasirKuPro',
      theme: _buildTheme(Brightness.light),
      darkTheme: _buildTheme(Brightness.dark),
      themeMode: _themeMode,
      home: MainShell(
        storeName: _storeName,
        onDarkMode: _setDarkMode,
        onStoreName: _setStoreName,
      ),
    );
  }
}

class Product {
  Product({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.cost,
    required this.stock,
    this.minStock = 5,
    this.sku = '',
    this.active = true,
  });

  final String id;
  String name;
  String category;
  int price;
  int cost;
  int stock;
  int minStock;
  String sku;
  bool active;

  bool get lowStock => active && stock <= minStock;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'category': category,
        'price': price,
        'cost': cost,
        'stock': stock,
        'minStock': minStock,
        'sku': sku,
        'active': active,
      };

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      id: '${json['id'] ?? DateTime.now().microsecondsSinceEpoch}',
      name: '${json['name'] ?? ''}',
      category: '${json['category'] ?? 'Lainnya'}',
      price: _toInt(json['price']),
      cost: _toInt(json['cost']),
      stock: _toInt(json['stock']),
      minStock: _toInt(json['minStock'], fallback: 5),
      sku: '${json['sku'] ?? ''}',
      active: json['active'] != false,
    );
  }
}

class CartItem {
  CartItem({required this.product, this.qty = 1});

  final Product product;
  int qty;

  int get total => product.price * qty;
  int get profit => (product.price - product.cost) * qty;
}

class TransactionLine {
  TransactionLine({
    required this.productId,
    required this.name,
    required this.price,
    required this.cost,
    required this.qty,
  });

  final String productId;
  final String name;
  final int price;
  final int cost;
  final int qty;

  int get total => price * qty;
  int get profit => (price - cost) * qty;

  Map<String, dynamic> toJson() => {
        'productId': productId,
        'name': name,
        'price': price,
        'cost': cost,
        'qty': qty,
      };

  factory TransactionLine.fromJson(Map<String, dynamic> json) {
    return TransactionLine(
      productId: '${json['productId'] ?? ''}',
      name: '${json['name'] ?? ''}',
      price: _toInt(json['price']),
      cost: _toInt(json['cost']),
      qty: _toInt(json['qty'], fallback: 1),
    );
  }
}

class SaleTransaction {
  SaleTransaction({
    required this.id,
    required this.createdAt,
    required this.method,
    required this.lines,
    required this.subtotal,
    required this.discount,
    required this.tax,
    required this.total,
    required this.paid,
    required this.change,
  });

  final String id;
  final DateTime createdAt;
  final String method;
  final List<TransactionLine> lines;
  final int subtotal;
  final int discount;
  final int tax;
  final int total;
  final int paid;
  final int change;

  int get qty => lines.fold(0, (sum, line) => sum + line.qty);
  int get profit => lines.fold(0, (sum, line) => sum + line.profit);

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'method': method,
        'lines': lines.map((line) => line.toJson()).toList(),
        'subtotal': subtotal,
        'discount': discount,
        'tax': tax,
        'total': total,
        'paid': paid,
        'change': change,
      };

  factory SaleTransaction.fromJson(Map<String, dynamic> json) {
    final rawLines = (json['lines'] as List?) ?? const [];
    return SaleTransaction(
      id: '${json['id'] ?? ''}',
      createdAt:
          DateTime.tryParse('${json['createdAt'] ?? ''}') ?? DateTime.now(),
      method: '${json['method'] ?? 'Tunai'}',
      lines: rawLines
          .whereType<Map>()
          .map((e) => TransactionLine.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
      subtotal: _toInt(json['subtotal']),
      discount: _toInt(json['discount']),
      tax: _toInt(json['tax']),
      total: _toInt(json['total']),
      paid: _toInt(json['paid']),
      change: _toInt(json['change']),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.storeName,
    required this.onDarkMode,
    required this.onStoreName,
  });

  final String storeName;
  final ValueChanged<bool> onDarkMode;
  final ValueChanged<String> onStoreName;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  bool _loading = true;
  final List<Product> _products = <Product>[];
  final List<SaleTransaction> _transactions = <SaleTransaction>[];

  bool _lowStockAlert = true;
  bool _autoPrint = false;
  bool _cashierSound = true;
  String _paper = '58 mm';
  String _printerName = 'Belum terhubung';
  String _printerMac = '';
  String _storeAddress = '';
  String _storePhone = '';
  int _taxPercent = 0;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final productRaw = prefs.getString('products_v3');
    final transactionRaw = prefs.getString('transactions_v3');
    if (productRaw != null && productRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(productRaw) as List<dynamic>;
        _products
          ..clear()
          ..addAll(decoded.whereType<Map>().map(
              (e) => Product.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    }
    if (transactionRaw != null && transactionRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(transactionRaw) as List<dynamic>;
        _transactions
          ..clear()
          ..addAll(decoded.whereType<Map>().map(
              (e) => SaleTransaction.fromJson(Map<String, dynamic>.from(e))));
      } catch (_) {}
    }
    setState(() {
      _lowStockAlert = prefs.getBool('low_stock_alert') ?? true;
      _autoPrint = prefs.getBool('auto_print') ?? false;
      _cashierSound = prefs.getBool('cashier_sound') ?? true;
      _paper = prefs.getString('paper_size') ?? '58 mm';
      _printerName = prefs.getString('printer_name') ?? 'Belum terhubung';
      _printerMac = prefs.getString('printer_mac') ?? '';
      _storeAddress = prefs.getString('store_address') ?? '';
      _storePhone = prefs.getString('store_phone') ?? '';
      _taxPercent = prefs.getInt('tax_percent') ?? 0;
      _loading = false;
    });
  }

  Future<void> _persistData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'products_v3',
      jsonEncode(_products.map((product) => product.toJson()).toList()),
    );
    await prefs.setString(
      'transactions_v3',
      jsonEncode(
        _transactions.map((transaction) => transaction.toJson()).toList(),
      ),
    );
  }

  Future<void> _persistSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('low_stock_alert', _lowStockAlert);
    await prefs.setBool('auto_print', _autoPrint);
    await prefs.setBool('cashier_sound', _cashierSound);
    await prefs.setString('paper_size', _paper);
    await prefs.setString('printer_name', _printerName);
    await prefs.setString('printer_mac', _printerMac);
    await prefs.setString('store_address', _storeAddress);
    await prefs.setString('store_phone', _storePhone);
    await prefs.setInt('tax_percent', _taxPercent);
  }

  void _go(int value) {
    setState(() => _index = value);
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

  Future<void> _saveProduct(Product product, {Product? existing}) async {
    setState(() {
      if (existing == null) {
        _products.add(product);
      }
    });
    await _persistData();
    if (mounted) setState(() {});
  }

  Future<void> _deleteProduct(Product product) async {
    setState(() => product.active = false);
    await _persistData();
  }

  Future<void> _voidTransaction(SaleTransaction transaction) async {
    for (final line in transaction.lines) {
      for (final product in _products) {
        if (product.id == line.productId) {
          product.stock += line.qty;
          break;
        }
      }
    }
    setState(() {
      _transactions.removeWhere((t) => t.id == transaction.id);
    });
    await _persistData();
  }

  Future<void> _completeSale(SaleTransaction transaction) async {
    for (final line in transaction.lines) {
      Product? product;
      for (final candidate in _products) {
        if (candidate.id == line.productId) {
          product = candidate;
          break;
        }
      }
      if (product != null) {
        product.stock = (product.stock - line.qty).clamp(0, 1 << 30);
      }
    }
    setState(() {
      _transactions.insert(0, transaction);
    });
    await _persistData();
  }

  int get _todaySales {
    final now = DateTime.now();
    return _transactions
        .where((t) => _sameDay(t.createdAt, now))
        .fold(0, (sum, t) => sum + t.total);
  }

  int get _todayTransactions =>
      _transactions.where((t) => _sameDay(t.createdAt, DateTime.now())).length;

  int get _todayProfit => _transactions
      .where((t) => _sameDay(t.createdAt, DateTime.now()))
      .fold(0, (sum, t) => sum + t.profit);

  int get _todayQty => _transactions
      .where((t) => _sameDay(t.createdAt, DateTime.now()))
      .fold(0, (sum, t) => sum + t.qty);

  @override
  Widget build(BuildContext context) {
    final titles = <String>[
      'Kasir',
      'Produk & Stok',
      'Transaksi',
      'Laporan',
      'Pengaturan',
    ];

    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      drawer: AppDrawer(
        storeName: widget.storeName,
        currentIndex: _index,
        onSelect: _go,
        lowStockCount:
            _lowStockAlert ? _products.where((p) => p.lowStock).length : 0,
      ),
      appBar: AppBar(
        leading: Builder(
          builder: (context) => IconButton(
            tooltip: 'Menu',
            onPressed: () => Scaffold.of(context).openDrawer(),
            icon: const Icon(Icons.menu_rounded),
          ),
        ),
        title: Text(
          titles[_index],
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          if (_index == 0)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: IconButton.filledTonal(
                tooltip: 'Stok menipis',
                onPressed: () => _go(1),
                icon: Badge(
                  isLabelVisible:
                      _lowStockAlert && _products.any((p) => p.lowStock),
                  label: Text('${_products.where((p) => p.lowStock).length}'),
                  child: const Icon(Icons.notifications_none_rounded),
                ),
              ),
            ),
        ],
      ),
      body: SafeArea(
        child: IndexedStack(
          index: _index,
          children: [
            CashierPage(
              products: _products,
              taxPercent: _taxPercent,
              autoPrint: _autoPrint,
              printerName: _printerName,
              printerMac: _printerMac,
              paper: _paper,
              storeName: widget.storeName,
              storeAddress: _storeAddress,
              storePhone: _storePhone,
              onNeedProduct: () => _go(1),
              onCompleteSale: _completeSale,
            ),
            ProductsPage(
              products: _products,
              onAdd: _saveProduct,
              onUpdate: () async {
                await _persistData();
                if (mounted) setState(() {});
              },
              onDelete: _deleteProduct,
            ),
            TransactionsPage(
              transactions: _transactions,
              onRefresh: () => setState(() {}),
              onVoid: _voidTransaction,
            ),
            ReportsPage(
              transactions: _transactions,
              products: _products,
              todaySales: _todaySales,
              todayTransactions: _todayTransactions,
              todayProfit: _todayProfit,
              todayQty: _todayQty,
            ),
            SettingsPage(
              storeName: widget.storeName,
              storeAddress: _storeAddress,
              storePhone: _storePhone,
              autoPrint: _autoPrint,
              lowStockAlert: _lowStockAlert,
              cashierSound: _cashierSound,
              paper: _paper,
              printerName: _printerName,
              printerMac: _printerMac,
              taxPercent: _taxPercent,
              onDarkMode: widget.onDarkMode,
              onStoreSave: (name, address, phone) async {
                await widget.onStoreName(name);
                setState(() {
                  _storeAddress = address;
                  _storePhone = phone;
                });
                await _persistSettings();
              },
              onSettingChanged: (values) async {
                setState(() {
                  _autoPrint = values.autoPrint;
                  _lowStockAlert = values.lowStockAlert;
                  _cashierSound = values.cashierSound;
                  _paper = values.paper;
                  _printerName = values.printerName;
                  _printerMac = values.printerMac;
                  _taxPercent = values.taxPercent;
                });
                await _persistSettings();
              },
            ),
          ],
        ),
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({
    super.key,
    required this.storeName,
    required this.currentIndex,
    required this.onSelect,
    required this.lowStockCount,
  });

  final String storeName;
  final int currentIndex;
  final ValueChanged<int> onSelect;
  final int lowStockCount;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return NavigationDrawer(
      selectedIndex: currentIndex,
      onDestinationSelected: onSelect,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 34, 20, 18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: brandSoft,
                child: const Icon(Icons.storefront_rounded, color: brand),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      storeName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    Text(
                      'Professional POS',
                      style: TextStyle(
                        color: scheme.onSurfaceVariant,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Divider(indent: 18, endIndent: 18),
        const SectionLabel('OPERASIONAL'),
        const NavigationDrawerDestination(
          icon: Icon(Icons.point_of_sale_outlined),
          selectedIcon: Icon(Icons.point_of_sale_rounded),
          label: Text('Kasir'),
        ),
        NavigationDrawerDestination(
          icon: Badge(
            isLabelVisible: lowStockCount > 0,
            label: Text('$lowStockCount'),
            child: const Icon(Icons.inventory_2_outlined),
          ),
          selectedIcon: const Icon(Icons.inventory_2_rounded),
          label: const Text('Produk & Stok'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.receipt_long_outlined),
          selectedIcon: Icon(Icons.receipt_long_rounded),
          label: Text('Transaksi'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.bar_chart_outlined),
          selectedIcon: Icon(Icons.bar_chart_rounded),
          label: Text('Laporan'),
        ),
        const SectionLabel('SISTEM'),
        const NavigationDrawerDestination(
          icon: Icon(Icons.settings_outlined),
          selectedIcon: Icon(Icons.settings_rounded),
          label: Text('Pengaturan'),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(28, 20, 28, 16),
          child: Text(
            'Drawer di kiri menjadi pusat akses semua operasional kasir.',
            style: TextStyle(fontSize: 12),
          ),
        ),
      ],
    );
  }
}

class CashierPage extends StatefulWidget {
  const CashierPage({
    super.key,
    required this.products,
    required this.taxPercent,
    required this.autoPrint,
    required this.printerName,
    required this.printerMac,
    required this.paper,
    required this.storeName,
    required this.storeAddress,
    required this.storePhone,
    required this.onNeedProduct,
    required this.onCompleteSale,
  });

  final List<Product> products;
  final int taxPercent;
  final bool autoPrint;
  final String printerName;
  final String printerMac;
  final String paper;
  final String storeName;
  final String storeAddress;
  final String storePhone;
  final VoidCallback onNeedProduct;
  final Future<void> Function(SaleTransaction transaction) onCompleteSale;

  @override
  State<CashierPage> createState() => _CashierPageState();
}

class _CashierPageState extends State<CashierPage> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  String _category = 'Semua';
  final Map<String, CartItem> _cart = <String, CartItem>{};
  int _discount = 0;

  List<String> get _categories {
    final values = widget.products
        .where((p) => p.active)
        .map((p) => p.category)
        .toSet()
        .toList();
    values.sort();
    return ['Semua', ...values];
  }

  List<Product> get _filteredProducts {
    final query = _query.toLowerCase().trim();
    return widget.products.where((product) {
      if (!product.active) return false;
      final searchMatch = query.isEmpty ||
          product.name.toLowerCase().contains(query) ||
          product.sku.toLowerCase().contains(query);
      final categoryMatch = _category == 'Semua' || product.category == _category;
      return searchMatch && categoryMatch;
    }).toList();
  }

  int get _subtotal => _cart.values.fold(0, (sum, item) => sum + item.total);

  int get _tax => ((_subtotal - _discount).clamp(0, 1 << 30) * widget.taxPercent) ~/ 100;

  int get _total => (_subtotal - _discount + _tax).clamp(0, 1 << 30);

  int get _count => _cart.values.fold(0, (sum, item) => sum + item.qty);

  void _add(Product product) {
    if (product.stock <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Stok produk habis.')),
      );
      return;
    }
    setState(() {
      final current = _cart[product.id];
      if (current == null) {
        _cart[product.id] = CartItem(product: product);
      } else if (current.qty < product.stock) {
        current.qty++;
      }
    });
  }

  void _remove(Product product) {
    final item = _cart[product.id];
    if (item == null) return;
    setState(() {
      if (item.qty <= 1) {
        _cart.remove(product.id);
      } else {
        item.qty--;
      }
    });
  }

  Future<void> _checkout() async {
    if (_cart.isEmpty) return;
    if (_cart.values.any((item) => item.qty > item.product.stock)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Jumlah barang melebihi stok tersedia.')),
      );
      return;
    }

    final lines = _cart.values
        .map(
          (item) => TransactionLine(
            productId: item.product.id,
            name: item.product.name,
            price: item.product.price,
            cost: item.product.cost,
            qty: item.qty,
          ),
        )
        .toList(growable: false);

    final transaction = await showModalBottomSheet<SaleTransaction>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => PaymentSheet(
        lines: lines,
        subtotal: _subtotal,
        discount: _discount,
        tax: _tax,
        total: _total,
        storeName: widget.storeName,
        storeAddress: widget.storeAddress,
        storePhone: widget.storePhone,
      ),
    );

    if (!mounted || transaction == null) return;
    await widget.onCompleteSale(transaction);
    setState(() {
      _cart.clear();
      _discount = 0;
    });

    if (widget.autoPrint && widget.printerMac.isNotEmpty) {
      await _printReceipt(transaction);
    } else {
      _showSaleDone(transaction);
    }
  }

  Future<void> _printReceipt(SaleTransaction transaction) async {
    try {
      final connected = await PrintBluetoothThermal.connectionStatus;
      if (!connected) {
        final ok = await PrintBluetoothThermal.connect(
          macPrinterAddress: widget.printerMac,
        );
        if (!ok) {
          _showSaleDone(transaction, message: 'Transaksi tersimpan, printer tidak terhubung.');
          return;
        }
      }
      final divider = widget.paper == '80 mm'
          ? '------------------------------------------------'
          : '--------------------------------';
      final lines = <String>[
        '',
        widget.storeName,
        if (widget.storeAddress.isNotEmpty) widget.storeAddress,
        if (widget.storePhone.isNotEmpty) widget.storePhone,
        divider,
        'No: ${transaction.id}',
        formatDateTime(transaction.createdAt),
        divider,
        ...transaction.lines.map(
          (line) => '${line.name}\n${line.qty} x ${formatCurrency(line.price)} = ${formatCurrency(line.total)}',
        ),
        divider,
        'Subtotal : ${formatCurrency(transaction.subtotal)}',
        if (transaction.discount > 0)
          'Diskon   : ${formatCurrency(transaction.discount)}',
        if (transaction.tax > 0)
          'Pajak    : ${formatCurrency(transaction.tax)}',
        'TOTAL    : ${formatCurrency(transaction.total)}',
        'Bayar    : ${formatCurrency(transaction.paid)}',
        'Kembali  : ${formatCurrency(transaction.change)}',
        'Metode   : ${transaction.method}',
        divider,
        'Terima kasih',
        '',
      ];
      final ok = await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(size: 1, text: lines.join('\n')),
      );
      _showSaleDone(
        transaction,
        message: ok ? 'Transaksi berhasil dan struk dicetak.' : 'Transaksi tersimpan, cetak gagal.',
      );
    } catch (_) {
      _showSaleDone(transaction, message: 'Transaksi tersimpan, cetak gagal.');
    }
  }

  void _showSaleDone(SaleTransaction transaction, {String? message}) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Transaksi berhasil'),
        content: Text(
          message ??
              'Total ${formatCurrency(transaction.total)}\nNo. ${transaction.id}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Selesai'),
          ),
        ],
      ),
    );
  }

  Future<void> _setDiscount() async {
    final controller = TextEditingController(text: '$_discount');
    final value = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Diskon transaksi'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(
            labelText: 'Nominal diskon',
            prefixText: 'Rp ',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, int.tryParse(controller.text) ?? 0),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null) return;
    setState(() => _discount = value.clamp(0, _subtotal));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final categories = _categories;
    if (_category != 'Semua' && !categories.contains(_category)) {
      _category = 'Semua';
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) => setState(() => _query = value),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search_rounded),
                    hintText: 'Cari produk / SKU...',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: 'Barcode',
                onPressed: () => _showBarcodeInfo(),
                icon: const Icon(Icons.qr_code_scanner_rounded),
              ),
            ],
          ),
        ),
        SizedBox(
          height: 42,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, index) {
              final category = categories[index];
              return ChoiceChip(
                label: Text(category),
                selected: category == _category,
                onSelected: (_) => setState(() => _category = category),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: _filteredProducts.isEmpty
              ? Padding(
                  padding: const EdgeInsets.all(16),
                  child: EmptyCard(
                    icon: Icons.point_of_sale_outlined,
                    title: widget.products.where((p) => p.active).isEmpty
                        ? 'Kasir siap digunakan'
                        : 'Produk tidak ditemukan',
                    text: widget.products.where((p) => p.active).isEmpty
                        ? 'Tambahkan produk terlebih dahulu untuk memulai penjualan.'
                        : 'Coba kata kunci atau kategori lain.',
                    actionLabel:
                        widget.products.where((p) => p.active).isEmpty ? 'Tambah produk' : null,
                    action: widget.products.where((p) => p.active).isEmpty
                        ? widget.onNeedProduct
                        : null,
                  ),
                )
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                    childAspectRatio: .80,
                  ),
                  itemCount: _filteredProducts.length,
                  itemBuilder: (_, index) {
                    final product = _filteredProducts[index];
                    final inCart = _cart[product.id]?.qty ?? 0;
                    final out = product.stock <= 0;
                    return Card(
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: out ? null : () => _add(product),
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                height: 72,
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  color: out
                                      ? scheme.surfaceContainerHighest
                                      : scheme.primaryContainer,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: Icon(
                                  product.category == 'Minuman'
                                      ? Icons.local_drink_rounded
                                      : product.category == 'Makanan'
                                          ? Icons.restaurant_rounded
                                          : Icons.inventory_2_rounded,
                                  size: 34,
                                  color: out ? scheme.outline : scheme.primary,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                product.category,
                                style: TextStyle(
                                  fontSize: 11,
                                  color: scheme.onSurfaceVariant,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                product.name,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w900),
                              ),
                              const Spacer(),
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      formatCurrency(product.price),
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w900,
                                      ),
                                    ),
                                  ),
                                  Text(
                                    out ? 'Habis' : 'Stok ${product.stock}',
                                    style: TextStyle(
                                      fontSize: 11,
                                      color: out
                                          ? scheme.error
                                          : scheme.onSurfaceVariant,
                                    ),
                                  ),
                                ],
                              ),
                              if (inCart > 0) ...[
                                const SizedBox(height: 8),
                                Row(
                                  children: [
                                    IconButton.filledTonal(
                                      visualDensity: VisualDensity.compact,
                                      onPressed: () => _remove(product),
                                      icon: const Icon(Icons.remove_rounded),
                                    ),
                                    Expanded(
                                      child: Center(
                                        child: Text(
                                          '$inCart',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w900,
                                          ),
                                        ),
                                      ),
                                    ),
                                    IconButton.filledTonal(
                                      visualDensity: VisualDensity.compact,
                                      onPressed: () => _add(product),
                                      icon: const Icon(Icons.add_rounded),
                                    ),
                                  ],
                                ),
                              ],
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
        if (_cart.isNotEmpty)
          _CartBar(
            count: _count,
            subtotal: _subtotal,
            discount: _discount,
            tax: _tax,
            total: _total,
            onDiscount: _setDiscount,
            onCheckout: _checkout,
          ),
      ],
    );
  }

  void _showBarcodeInfo() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Barcode / SKU'),
        content: const Text(
          'Gunakan kolom pencarian untuk scanner barcode USB/Bluetooth. Scanner yang bertindak sebagai keyboard akan langsung mengisi SKU.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Mengerti'),
          ),
        ],
      ),
    );
  }
}

class _CartBar extends StatelessWidget {
  const _CartBar({
    required this.count,
    required this.subtotal,
    required this.discount,
    required this.tax,
    required this.total,
    required this.onDiscount,
    required this.onCheckout,
  });

  final int count;
  final int subtotal;
  final int discount;
  final int tax;
  final int total;
  final VoidCallback onDiscount;
  final VoidCallback onCheckout;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Card(
        margin: const EdgeInsets.fromLTRB(12, 4, 12, 12),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
          child: Column(
            children: [
              Row(
                children: [
                  Text(
                    '$count item',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: onDiscount,
                    icon: const Icon(Icons.local_offer_outlined),
                    label: Text(
                      discount == 0 ? 'Diskon' : formatCurrency(discount),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Subtotal ${formatCurrency(subtotal)}'),
                        if (discount > 0)
                          Text('Diskon -${formatCurrency(discount)}'),
                        if (tax > 0) Text('Pajak ${formatCurrency(tax)}'),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  FilledButton(
                    onPressed: onCheckout,
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(150, 54),
                    ),
                    child: Text('Rp ${formatCurrency(total)}'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PaymentSheet extends StatefulWidget {
  const PaymentSheet({
    super.key,
    required this.lines,
    required this.subtotal,
    required this.discount,
    required this.tax,
    required this.total,
    required this.storeName,
    required this.storeAddress,
    required this.storePhone,
  });

  final List<TransactionLine> lines;
  final int subtotal;
  final int discount;
  final int tax;
  final int total;
  final String storeName;
  final String storeAddress;
  final String storePhone;

  @override
  State<PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends State<PaymentSheet> {
  final TextEditingController _amountController = TextEditingController();
  String _method = 'Tunai';

  int get _paid => int.tryParse(_amountController.text) ?? 0;
  int get _change => _paid - widget.total;

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        10,
        20,
        MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Pembayaran',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Text(
              'Total ${formatCurrency(widget.total)}',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['Tunai', 'QRIS', 'Transfer', 'Kartu'].map((method) {
                return ChoiceChip(
                  label: Text(method),
                  selected: _method == method,
                  onSelected: (_) => setState(() => _method = method),
                );
              }).toList(),
            ),
            const SizedBox(height: 14),
            if (_method == 'Tunai') ...[
              TextField(
                controller: _amountController,
                autofocus: true,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Uang diterima',
                  prefixText: 'Rp ',
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  const Text(
                    'Kembalian',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const Spacer(),
                  Text(
                    _change < 0
                        ? 'Kurang ${formatCurrency(-_change)}'
                        : formatCurrency(_change),
                    style: TextStyle(
                      fontWeight: FontWeight.w900,
                      color: _change < 0
                          ? Theme.of(context).colorScheme.error
                          : null,
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 18),
            FilledButton(
              onPressed: _method != 'Tunai' || _paid >= widget.total
                  ? () => Navigator.pop(context, _buildTransaction())
                  : null,
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54),
              ),
              child: const Text('Selesaikan Pembayaran'),
            ),
          ],
        ),
      ),
    );
  }

  SaleTransaction _buildTransaction() {
    return SaleTransaction(
      id: 'TRX-${DateTime.now().millisecondsSinceEpoch}',
      createdAt: DateTime.now(),
      method: _method,
      lines: widget.lines,
      subtotal: widget.subtotal,
      discount: widget.discount,
      tax: widget.tax,
      total: widget.total,
      paid: _method == 'Tunai' ? _paid : widget.total,
      change: _method == 'Tunai' ? _change.clamp(0, 1 << 30) : 0,
    );
  }
}

class ProductsPage extends StatefulWidget {
  const ProductsPage({
    super.key,
    required this.products,
    required this.onAdd,
    required this.onUpdate,
    required this.onDelete,
  });

  final List<Product> products;
  final Future<void> Function(Product product, {Product? existing}) onAdd;
  final Future<void> Function() onUpdate;
  final Future<void> Function(Product product) onDelete;

  @override
  State<ProductsPage> createState() => _ProductsPageState();
}

class _ProductsPageState extends State<ProductsPage> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  String _category = 'Semua';

  List<Product> get _list => widget.products.where((product) {
        if (!product.active) return false;
        final q = _query.toLowerCase().trim();
        final searchMatch = q.isEmpty ||
            product.name.toLowerCase().contains(q) ||
            product.sku.toLowerCase().contains(q);
        final categoryMatch = _category == 'Semua' || product.category == _category;
        return searchMatch && categoryMatch;
      }).toList();

  List<String> get _categories => [
        'Semua',
        ...widget.products.map((p) => p.category).toSet().toList()..sort(),
      ];

  Future<void> _showEditor({Product? product}) async {
    final name = TextEditingController(text: product?.name ?? '');
    final sku = TextEditingController(text: product?.sku ?? '');
    final price = TextEditingController(text: '${product?.price ?? ''}');
    final cost = TextEditingController(text: '${product?.cost ?? ''}');
    final stock = TextEditingController(text: '${product?.stock ?? 0}');
    final minStock = TextEditingController(text: '${product?.minStock ?? 5}');
    String category = product?.category ?? 'Makanan';

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) {
          return Padding(
            padding: EdgeInsets.fromLTRB(
              20,
              10,
              20,
              MediaQuery.of(context).viewInsets.bottom + 24,
            ),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product == null ? 'Tambah produk' : 'Edit produk',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(
                      labelText: 'Nama produk',
                      prefixIcon: Icon(Icons.inventory_2_outlined),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: sku,
                    decoration: const InputDecoration(
                      labelText: 'SKU / barcode',
                      prefixIcon: Icon(Icons.qr_code_2_rounded),
                    ),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: category,
                    decoration: const InputDecoration(labelText: 'Kategori'),
                    items: const [
                      DropdownMenuItem(value: 'Makanan', child: Text('Makanan')),
                      DropdownMenuItem(value: 'Minuman', child: Text('Minuman')),
                      DropdownMenuItem(value: 'Jasa', child: Text('Jasa')),
                      DropdownMenuItem(value: 'Lainnya', child: Text('Lainnya')),
                    ],
                    onChanged: (value) {
                      if (value != null) setSheetState(() => category = value);
                    },
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: price,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          decoration: const InputDecoration(
                            labelText: 'Harga jual',
                            prefixText: 'Rp ',
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: cost,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          decoration: const InputDecoration(
                            labelText: 'Harga modal',
                            prefixText: 'Rp ',
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: stock,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          decoration: const InputDecoration(labelText: 'Stok'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: minStock,
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                          decoration: const InputDecoration(labelText: 'Minimum stok'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  FilledButton(
                    onPressed: () async {
                      final productName = name.text.trim();
                      final productPrice = int.tryParse(price.text) ?? 0;
                      final productCost = int.tryParse(cost.text) ?? 0;
                      final productStock = int.tryParse(stock.text) ?? 0;
                      final productMinStock = int.tryParse(minStock.text) ?? 5;
                      if (productName.isEmpty || productPrice <= 0) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Nama dan harga jual wajib diisi.'),
                          ),
                        );
                        return;
                      }

                      if (product == null) {
                        await widget.onAdd(
                          Product(
                            id: DateTime.now().microsecondsSinceEpoch.toString(),
                            name: productName,
                            category: category,
                            price: productPrice,
                            cost: productCost,
                            stock: productStock,
                            minStock: productMinStock,
                            sku: sku.text.trim(),
                          ),
                        );
                      } else {
                        setState(() {
                          product.name = productName;
                          product.category = category;
                          product.price = productPrice;
                          product.cost = productCost;
                          product.stock = productStock;
                          product.minStock = productMinStock;
                          product.sku = sku.text.trim();
                        });
                        await widget.onUpdate();
                      }
                      if (context.mounted) Navigator.pop(context, true);
                    },
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(54),
                    ),
                    child: Text(product == null ? 'Simpan produk' : 'Simpan perubahan'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );

    name.dispose();
    sku.dispose();
    price.dispose();
    cost.dispose();
    stock.dispose();
    minStock.dispose();

    if (saved == true && mounted) setState(() {});
  }

  Future<void> _delete(Product product) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Nonaktifkan produk?'),
        content: Text('Produk "${product.name}" tidak akan muncul di kasir lagi.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Nonaktifkan'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await widget.onDelete(product);
      if (mounted) setState(() {});
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = _categories;
    if (!categories.contains(_category)) _category = 'Semua';
    final low = _list.where((p) => p.lowStock).length;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Produk & Stok',
                    style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900),
                  ),
                  SizedBox(height: 4),
                  Text('Kelola harga, modal, SKU, stok, dan produk aktif.'),
                ],
              ),
            ),
            FilledButton.icon(
              onPressed: () => _showEditor(),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Tambah'),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _query = value),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search_rounded),
                  hintText: 'Cari produk / SKU...',
                ),
              ),
            ),
            const SizedBox(width: 10),
            if (low > 0)
              Chip(
                avatar: const Icon(Icons.warning_amber_rounded, size: 18),
                label: Text('$low stok menipis'),
              ),
          ],
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: categories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (_, index) {
              final category = categories[index];
              return ChoiceChip(
                label: Text(category),
                selected: category == _category,
                onSelected: (_) => setState(() => _category = category),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        if (_list.isEmpty)
          const EmptyCard(
            icon: Icons.inventory_2_outlined,
            title: 'Belum ada produk',
            text: 'Tambahkan produk untuk mengaktifkan kasir.',
          )
        else
          ..._list.map(
            (product) => Card(
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 4,
                ),
                leading: CircleAvatar(
                  backgroundColor: product.lowStock ? Colors.orange.shade50 : brandSoft,
                  child: Icon(
                    product.lowStock
                        ? Icons.warning_amber_rounded
                        : Icons.inventory_2_rounded,
                    color: product.lowStock ? Colors.orange.shade800 : brand,
                  ),
                ),
                title: Text(
                  product.name,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: Text(
                  '${product.category} • ${product.sku.isEmpty ? 'Tanpa SKU' : product.sku}\nStok ${product.stock} • Modal ${formatCurrency(product.cost)}',
                ),
                isThreeLine: true,
                trailing: SizedBox(
                  width: 120,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Text(
                          formatCurrency(product.price),
                          textAlign: TextAlign.end,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (value) async {
                          if (value == 'edit') {
                            await _showEditor(product: product);
                          } else if (value == 'delete') {
                            await _delete(product);
                          }
                        },
                        itemBuilder: (context) => const [
                          PopupMenuItem(value: 'edit', child: Text('Edit')),
                          PopupMenuItem(value: 'delete', child: Text('Nonaktifkan')),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class TransactionsPage extends StatefulWidget {
  const TransactionsPage({
    super.key,
    required this.transactions,
    required this.onRefresh,
    required this.onVoid,
  });

  final List<SaleTransaction> transactions;
  final VoidCallback onRefresh;
  final Future<void> Function(SaleTransaction transaction) onVoid;

  @override
  State<TransactionsPage> createState() => _TransactionsPageState();
}

class _TransactionsPageState extends State<TransactionsPage> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  String _method = 'Semua';

  List<SaleTransaction> get _filtered {
    final q = _query.toLowerCase().trim();
    return widget.transactions.where((transaction) {
      final search = q.isEmpty ||
          transaction.id.toLowerCase().contains(q) ||
          transaction.lines.any((line) => line.name.toLowerCase().contains(q));
      final method = _method == 'Semua' || transaction.method == _method;
      return search && method;
    }).toList();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final today = widget.transactions
        .where((t) => _sameDay(t.createdAt, DateTime.now()))
        .fold(0, (sum, t) => sum + t.total);

    return RefreshIndicator(
      onRefresh: () async => widget.onRefresh(),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Transaksi',
            style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 4),
          const Text('Riwayat penjualan tersimpan di perangkat.'),
          const SizedBox(height: 16),
          MetricCard(
            label: 'Omzet hari ini',
            value: formatCurrency(today),
            icon: Icons.payments_rounded,
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) => setState(() => _query = value),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search_rounded),
                    hintText: 'Cari no. transaksi / produk...',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _method,
                  items: const [
                    DropdownMenuItem(value: 'Semua', child: Text('Semua')),
                    DropdownMenuItem(value: 'Tunai', child: Text('Tunai')),
                    DropdownMenuItem(value: 'QRIS', child: Text('QRIS')),
                    DropdownMenuItem(value: 'Transfer', child: Text('Transfer')),
                    DropdownMenuItem(value: 'Kartu', child: Text('Kartu')),
                  ],
                  onChanged: (value) {
                    if (value != null) setState(() => _method = value);
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (_filtered.isEmpty)
            const EmptyCard(
              icon: Icons.receipt_long_outlined,
              title: 'Belum ada transaksi',
              text: 'Riwayat penjualan akan tampil di sini setelah checkout.',
            )
          else
            ..._filtered.map(
              (transaction) => Card(
                child: ListTile(
                  onTap: () => _showDetail(transaction),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 5,
                  ),
                  leading: CircleAvatar(
                    backgroundColor: brandSoft,
                    child: const Icon(Icons.receipt_long_rounded, color: brand),
                  ),
                  title: Text(
                    transaction.id,
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                  subtitle: Text(
                    '${formatDateTime(transaction.createdAt)} • ${transaction.method} • ${transaction.qty} item',
                  ),
                  trailing: SizedBox(
                    width: 120,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            formatCurrency(transaction.total),
                            textAlign: TextAlign.end,
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (value) async {
                            if (value == 'void') {
                              final confirmed = await showDialog<bool>(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('Batalkan transaksi?'),
                                  content: const Text(
                                    'Transaksi akan dihapus dari riwayat dan stok barang dikembalikan.',
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.pop(context, false),
                                      child: const Text('Batal'),
                                    ),
                                    FilledButton(
                                      onPressed: () => Navigator.pop(context, true),
                                      child: const Text('Batalkan'),
                                    ),
                                  ],
                                ),
                              );
                              if (confirmed == true) {
                                await widget.onVoid(transaction);
                                if (mounted) setState(() {});
                              }
                            }
                          },
                          itemBuilder: (context) => const [
                            PopupMenuItem(
                              value: 'void',
                              child: Text('Batalkan transaksi'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _showDetail(SaleTransaction transaction) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 10, 20, 30),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                transaction.id,
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 4),
              Text(formatDateTime(transaction.createdAt)),
              const SizedBox(height: 14),
              ...transaction.lines.map(
                (line) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(line.name),
                  subtitle: Text('${line.qty} x ${formatCurrency(line.price)}'),
                  trailing: Text(
                    formatCurrency(line.total),
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ),
              const Divider(),
              SummaryRow(label: 'Subtotal', value: transaction.subtotal),
              if (transaction.discount > 0)
                SummaryRow(label: 'Diskon', value: transaction.discount, negative: true),
              if (transaction.tax > 0)
                SummaryRow(label: 'Pajak', value: transaction.tax),
              SummaryRow(label: 'Total', value: transaction.total, strong: true),
              SummaryRow(label: 'Bayar', value: transaction.paid),
              SummaryRow(label: 'Kembali', value: transaction.change),
            ],
          ),
        ),
      ),
    );
  }
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({
    super.key,
    required this.transactions,
    required this.products,
    required this.todaySales,
    required this.todayTransactions,
    required this.todayProfit,
    required this.todayQty,
  });

  final List<SaleTransaction> transactions;
  final List<Product> products;
  final int todaySales;
  final int todayTransactions;
  final int todayProfit;
  final int todayQty;

  @override
  Widget build(BuildContext context) {
    final topProducts = <String, int>{};
    for (final transaction in transactions.where(
      (t) => _sameDay(t.createdAt, DateTime.now()),
    )) {
      for (final line in transaction.lines) {
        topProducts[line.name] = (topProducts[line.name] ?? 0) + line.qty;
      }
    }
    final ranked = topProducts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Laporan',
          style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 4),
        const Text('Ringkasan performa toko untuk keputusan operasional.'),
        const SizedBox(height: 18),
        Row(
          children: [
            Expanded(
              child: MetricCard(
                label: 'Omzet hari ini',
                value: formatCurrency(todaySales),
                icon: Icons.payments_rounded,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: MetricCard(
                label: 'Transaksi',
                value: '$todayTransactions',
                icon: Icons.receipt_long_rounded,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: MetricCard(
                label: 'Laba kotor',
                value: formatCurrency(todayProfit),
                icon: Icons.trending_up_rounded,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: MetricCard(
                label: 'Produk terjual',
                value: '$todayQty',
                icon: Icons.shopping_bag_rounded,
              ),
            ),
          ],
        ),
        const SizedBox(height: 18),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Produk terlaris hari ini',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 12),
                if (ranked.isEmpty)
                  const Text('Belum ada penjualan hari ini.')
                else
                  ...ranked.take(5).map(
                    (entry) => ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: brandSoft,
                        child: Text('${ranked.indexOf(entry) + 1}'),
                      ),
                      title: Text(
                        entry.key,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      trailing: Text('${entry.value} pcs'),
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Stok menipis',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 12),
                ...products.where((p) => p.lowStock).take(8).map(
                  (product) => ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.warning_amber_rounded),
                    title: Text(product.name),
                    trailing: Text('${product.stock}'),
                  ),
                ),
                if (products.where((p) => p.lowStock).isEmpty)
                  const Text('Semua stok berada di atas batas minimum.'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({
    super.key,
    required this.storeName,
    required this.storeAddress,
    required this.storePhone,
    required this.autoPrint,
    required this.lowStockAlert,
    required this.cashierSound,
    required this.paper,
    required this.printerName,
    required this.printerMac,
    required this.taxPercent,
    required this.onDarkMode,
    required this.onStoreSave,
    required this.onSettingChanged,
  });

  final String storeName;
  final String storeAddress;
  final String storePhone;
  final bool autoPrint;
  final bool lowStockAlert;
  final bool cashierSound;
  final String paper;
  final String printerName;
  final String printerMac;
  final int taxPercent;
  final ValueChanged<bool> onDarkMode;
  final Future<void> Function(String name, String address, String phone)
      onStoreSave;
  final Future<void> Function(SettingsState values) onSettingChanged;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class SettingsState {
  SettingsState({
    required this.autoPrint,
    required this.lowStockAlert,
    required this.cashierSound,
    required this.paper,
    required this.printerName,
    required this.printerMac,
    required this.taxPercent,
  });

  final bool autoPrint;
  final bool lowStockAlert;
  final bool cashierSound;
  final String paper;
  final String printerName;
  final String printerMac;
  final int taxPercent;
}

class _SettingsPageState extends State<SettingsPage> {
  late bool _autoPrint = widget.autoPrint;
  late bool _lowStockAlert = widget.lowStockAlert;
  late bool _cashierSound = widget.cashierSound;
  late String _paper = widget.paper;
  late String _printerName = widget.printerName;
  late String _printerMac = widget.printerMac;
  late int _taxPercent = widget.taxPercent;

  SettingsState _state() => SettingsState(
        autoPrint: _autoPrint,
        lowStockAlert: _lowStockAlert,
        cashierSound: _cashierSound,
        paper: _paper,
        printerName: _printerName,
        printerMac: _printerMac,
        taxPercent: _taxPercent,
      );

  Future<void> _persist() async {
    await widget.onSettingChanged(_state());
  }

  Future<void> _editStore() async {
    final name = TextEditingController(text: widget.storeName);
    final address = TextEditingController(text: widget.storeAddress);
    final phone = TextEditingController(text: widget.storePhone);
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          10,
          20,
          MediaQuery.of(context).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Profil toko',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: name,
              decoration: const InputDecoration(
                labelText: 'Nama toko',
                prefixIcon: Icon(Icons.storefront_outlined),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: address,
              decoration: const InputDecoration(
                labelText: 'Alamat toko',
                prefixIcon: Icon(Icons.location_on_outlined),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Nomor telepon',
                prefixIcon: Icon(Icons.phone_outlined),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(52),
              ),
              child: const Text('Simpan profil'),
            ),
          ],
        ),
      ),
    );
    if (saved == true) {
      await widget.onStoreSave(name.text, address.text, phone.text);
    }
    name.dispose();
    address.dispose();
    phone.dispose();
  }

  Future<void> _openPrinters() async {
    try {
      final paired = await PrintBluetoothThermal.pairedBluetooths;
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (context) => SizedBox(
          height: MediaQuery.of(context).size.height * .75,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Printer Bluetooth',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              const Text(
                'Pastikan printer thermal sudah dipasangkan melalui Bluetooth HP.',
              ),
              const SizedBox(height: 16),
              if (paired.isEmpty)
                const EmptyCard(
                  icon: Icons.print_disabled_rounded,
                  title: 'Tidak ada printer dipasangkan',
                  text: 'Pasangkan printer 58/80 mm di pengaturan Bluetooth Android.',
                )
              else
                ...paired.map(
                  (device) => Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        backgroundColor: brandSoft,
                        child: Icon(Icons.print_rounded, color: brand),
                      ),
                      title: Text(
                        device.name.isEmpty ? 'Printer Bluetooth' : device.name,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: Text(device.macAdress ?? '-'),
                      trailing: FilledButton(
                        onPressed: () => _connectPrinter(
                          device.name,
                          device.macAdress ?? '',
                        ),
                        child: const Text('Hubungkan'),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      _snack('Gagal membaca printer: $error');
    }
  }

  Future<void> _connectPrinter(String name, String mac) async {
    if (mac.isEmpty) {
      _snack('Alamat printer tidak tersedia.');
      return;
    }
    try {
      final ok = await PrintBluetoothThermal.connect(macPrinterAddress: mac);
      if (!mounted) return;
      if (ok) {
        setState(() {
          _printerName = name.isEmpty ? 'Printer Bluetooth' : name;
          _printerMac = mac;
        });
        await _persist();
        if (mounted) Navigator.pop(context);
        _snack('Printer berhasil terhubung.');
      } else {
        _snack('Printer gagal dihubungkan.');
      }
    } catch (error) {
      _snack('Koneksi printer gagal: $error');
    }
  }

  Future<void> _testPrint() async {
    try {
      var connected = await PrintBluetoothThermal.connectionStatus;
      if (!connected && _printerMac.isNotEmpty) {
        connected = await PrintBluetoothThermal.connect(
          macPrinterAddress: _printerMac,
        );
      }
      if (!connected) {
        _snack('Hubungkan printer terlebih dahulu.');
        return;
      }
      final divider = _paper == '80 mm'
          ? '------------------------------------------------'
          : '--------------------------------';
      final ok = await PrintBluetoothThermal.writeString(
        printText: PrintTextSize(
          size: 1,
          text: '\n${widget.storeName}\n$divider\nTES CETAK\n${formatDateTime(DateTime.now())}\n$divider\n\n',
        ),
      );
      _snack(ok ? 'Tes cetak berhasil.' : 'Tes cetak gagal.');
    } catch (error) {
      _snack('Tes cetak gagal: $error');
    }
  }

  Future<void> _setTax() async {
    final controller = TextEditingController(text: '$_taxPercent');
    final value = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Pajak transaksi'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(suffixText: '%'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, int.tryParse(controller.text) ?? 0),
            child: const Text('Simpan'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null) return;
    setState(() => _taxPercent = value.clamp(0, 100));
    await _persist();
  }

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 28,
                  backgroundColor: brandSoft,
                  child: Icon(Icons.storefront_rounded, color: brand),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.storeName,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        widget.storePhone.isEmpty
                            ? 'Kelola identitas dan perangkat operasional toko.'
                            : widget.storePhone,
                      ),
                    ],
                  ),
                ),
                IconButton(onPressed: _editStore, icon: const Icon(Icons.edit_rounded)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const SectionLabel('TOKO'),
        SettingTile(
          icon: Icons.store_outlined,
          title: 'Profil toko',
          subtitle: 'Nama, alamat, dan nomor telepon',
          onTap: _editStore,
        ),
        SettingTile(
          icon: Icons.percent_rounded,
          title: 'Pajak transaksi',
          subtitle: 'Pajak saat checkout • $_taxPercent%',
          onTap: _setTax,
        ),
        const SectionLabel('PRINTER & STRUK'),
        SettingTile(
          icon: Icons.print_outlined,
          title: 'Printer Bluetooth',
          subtitle: _printerMac.isEmpty
              ? 'Belum terhubung • Cari printer yang sudah dipasangkan'
              : '$_printerName • $_paper',
          onTap: _openPrinters,
        ),
        SettingTile(
          icon: Icons.receipt_long_outlined,
          title: 'Cetak tes',
          subtitle: 'Cek koneksi dan format struk',
          onTap: _testPrint,
        ),
        SettingSwitch(
          icon: Icons.autorenew_rounded,
          title: 'Cetak otomatis',
          subtitle: 'Cetak nota setelah pembayaran berhasil',
          value: _autoPrint,
          onChanged: (value) async {
            setState(() => _autoPrint = value);
            await _persist();
          },
        ),
        Card(
          child: ListTile(
            leading: const CircleAvatar(
              backgroundColor: brandSoft,
              child: Icon(Icons.straighten_rounded, color: brand),
            ),
            title: const Text(
              'Ukuran kertas',
              style: TextStyle(fontWeight: FontWeight.w900),
            ),
            subtitle: Text(_paper),
            trailing: DropdownButton<String>(
              value: _paper,
              items: const [
                DropdownMenuItem(value: '58 mm', child: Text('58 mm')),
                DropdownMenuItem(value: '80 mm', child: Text('80 mm')),
              ],
              onChanged: (value) async {
                if (value == null) return;
                setState(() => _paper = value);
                await _persist();
              },
            ),
          ),
        ),
        const SectionLabel('PENJUALAN'),
        SettingSwitch(
          icon: Icons.inventory_2_outlined,
          title: 'Peringatan stok menipis',
          subtitle: 'Tandai produk saat stok di bawah minimum',
          value: _lowStockAlert,
          onChanged: (value) async {
            setState(() => _lowStockAlert = value);
            await _persist();
          },
        ),
        SettingSwitch(
          icon: Icons.volume_up_outlined,
          title: 'Suara kasir',
          subtitle: 'Siapkan notifikasi suara untuk operasi kasir',
          value: _cashierSound,
          onChanged: (value) async {
            setState(() => _cashierSound = value);
            await _persist();
          },
        ),
        const SectionLabel('KEAMANAN & DATA'),
        SettingTile(
          icon: Icons.lock_outline_rounded,
          title: 'PIN kasir',
          subtitle: 'Siapkan kontrol akses sebelum operasional multi-user',
          onTap: () => _showInfo(
            'PIN kasir',
            'Struktur pengaturan sudah disiapkan untuk mode kasir dengan PIN. Aktifkan modul PIN saat toko mulai memakai banyak operator.',
          ),
        ),
        SettingTile(
          icon: Icons.backup_outlined,
          title: 'Backup & Pulihkan',
          subtitle: 'Data utama tersimpan lokal di perangkat',
          onTap: () => _showInfo(
            'Backup & Pulihkan',
            'Data produk, stok, dan transaksi disimpan lokal menggunakan penyimpanan aplikasi. Untuk keamanan tambahan, lakukan backup perangkat secara berkala.',
          ),
        ),
        SettingSwitch(
          icon: Icons.dark_mode_outlined,
          title: 'Mode gelap',
          subtitle: 'Tampilan nyaman untuk operasional malam',
          value: Theme.of(context).brightness == Brightness.dark,
          onChanged: widget.onDarkMode,
        ),
        const SizedBox(height: 18),
        const Center(
          child: Text(
            'KasirKuPro Professional POS • 3.0.0',
            style: TextStyle(fontSize: 12),
          ),
        ),
      ],
    );
  }

  void _showInfo(String title, String message) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }
}

class MetricCard extends StatelessWidget {
  const MetricCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: scheme.primary),
            const SizedBox(height: 12),
            Text(
              value,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}

class SummaryRow extends StatelessWidget {
  const SummaryRow({
    super.key,
    required this.label,
    required this.value,
    this.negative = false,
    this.strong = false,
  });

  final String label;
  final int value;
  final bool negative;
  final bool strong;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: strong ? FontWeight.w900 : FontWeight.w600,
            ),
          ),
          const Spacer(),
          Text(
            '${negative ? '-' : ''}${formatCurrency(value)}',
            style: TextStyle(fontWeight: strong ? FontWeight.w900 : FontWeight.w700),
          ),
        ],
      ),
    );
  }
}

class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
      child: Text(
        text,
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          fontSize: 11,
          fontWeight: FontWeight.w900,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class SettingTile extends StatelessWidget {
  const SettingTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.trailing,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        leading: CircleAvatar(
          backgroundColor: brandSoft,
          child: Icon(icon, color: brand),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(subtitle),
        trailing: trailing ?? const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}

class SettingSwitch extends StatelessWidget {
  const SettingSwitch({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SwitchListTile(
        value: value,
        onChanged: onChanged,
        contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        secondary: CircleAvatar(
          backgroundColor: brandSoft,
          child: Icon(icon, color: brand),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text(subtitle),
      ),
    );
  }
}

class EmptyCard extends StatelessWidget {
  const EmptyCard({
    super.key,
    required this.icon,
    required this.title,
    required this.text,
    this.actionLabel,
    this.action,
  });

  final IconData icon;
  final String title;
  final String text;
  final String? actionLabel;
  final VoidCallback? action;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            Icon(icon, size: 48, color: scheme.onSurfaceVariant),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(color: scheme.onSurfaceVariant),
            ),
            if (actionLabel != null && action != null) ...[
              const SizedBox(height: 14),
              FilledButton.tonalIcon(
                onPressed: action,
                icon: const Icon(Icons.add_rounded),
                label: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

String formatCurrency(int value) {
  final negative = value < 0;
  final digits = value.abs().toString();
  final formatted = digits.replaceAllMapped(
    RegExp(r'(?=(\d{3})+(?!\d))'),
    (_) => '.',
  );
  return '${negative ? '-' : ''}$formatted';
}

String formatDateTime(DateTime value) {
  String two(int v) => v.toString().padLeft(2, '0');
  return '${two(value.day)}/${two(value.month)}/${value.year} ${two(value.hour)}:${two(value.minute)}';
}

bool _sameDay(DateTime a, DateTime b) {
  return a.year == b.year && a.month == b.month && a.day == b.day;
}

int _toInt(dynamic value, {int fallback = 0}) {
  if (value is int) return value;
  return int.tryParse('$value') ?? fallback;
}
