# KasirKuPro Professional POS 4.0

UI dan arsitektur baru dibuat bergaya POS komersial modern, terinspirasi dari referensi yang diberikan: bersih, rounded, fokus pada aksi kasir, bottom navigation, dashboard ringkas, dan branch switcher.

## Multi-cabang
- Cabang dapat dibuat dan dipilih dari header aplikasi.
- Setiap cabang mempunyai daftar produk/stok sendiri.
- Setiap cabang mempunyai transaksi dan laporan sendiri.
- Pajak, printer, ukuran kertas, auto print, alamat, dan telepon tersimpan per cabang.
- Ganti cabang tidak mencampur stok atau transaksi antar cabang.
- Migrasi otomatis dari data lokal versi sebelumnya ke Cabang Pusat.

## UI
- Beranda modern dengan kartu omzet, transaksi, laba kotor.
- Aksi cepat Kasir, Produk Baru, Transaksi, Laporan.
- Bottom navigation 5 menu: Beranda, Kasir, Stok, Transaksi, Laporan.
- Header menampilkan toko + cabang aktif serta switcher cabang.
- Palet ungu modern seperti referensi UI.
- Tombol pengaturan dan indikator stok menipis.

## Fitur POS
- Pencarian produk, kategori, SKU/barcode, keranjang, diskon, pajak, checkout.
- Pembayaran tunai, QRIS, transfer, dan kartu.
- Riwayat transaksi dan pembatalan dengan pengembalian stok.
- Laporan omzet, transaksi, laba kotor, produk terjual, produk terlaris, dan stok menipis.
- Printer Bluetooth thermal 58/80 mm, tes cetak, dan auto print.
- Data lokal menggunakan SharedPreferences.

## Build
Workflow GitHub Actions menjalankan `flutter analyze`, `flutter test`, dan `flutter build apk --release` menggunakan Flutter stable 3.35.5.
