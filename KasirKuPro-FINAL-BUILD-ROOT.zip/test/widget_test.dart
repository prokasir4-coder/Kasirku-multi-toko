import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('KasirKuPro starts without demo data', (tester) async {
    await tester.pumpWidget(const KasirKuProApp());
    await tester.pumpAndSettle();
    expect(find.text('Rp 0'), findsOneWidget);
    expect(find.text('Belum ada transaksi hari ini'), findsOneWidget);
  });
}
