# KasirKuPro Professional POS

Versi build-fix untuk GitHub Actions.

## Build

Upload seluruh isi folder ini ke root repository GitHub, commit ke `main`, lalu buka **Actions → Build KasirKuPro APK**.

Workflow akan membuat Android project, mengambil dependency, menjalankan analyze/test, lalu menghasilkan APK release di Artifacts.

## Printer

Pasangkan printer thermal Bluetooth terlebih dahulu di pengaturan Bluetooth Android. Di aplikasi buka **Pengaturan → Printer & Struk → Cari perangkat printer**. Plugin `print_bluetooth_thermal` membaca perangkat Bluetooth yang sudah dipasangkan.
