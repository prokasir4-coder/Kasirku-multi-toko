# KasirKuPro Professional POS 2.1

POS Flutter modern dengan drawer kiri (buka/tutup dari ikon menu di pojok kiri atas), menu kasir, produk & stok, transaksi, laporan, dan pengaturan profesional.

## Fitur utama
- Drawer navigasi modern di pojok kiri atas.
- Kasir: pencarian produk/SKU, kategori, keranjang, jumlah item, checkout, dan metode pembayaran.
- Produk & stok: tambah produk, SKU/barcode, kategori, harga, dan stok.
- Transaksi dan laporan dengan empty state yang siap diisi data nyata.
- Pengaturan profesional: profil toko, metode pembayaran, printer, cetak tes, cetak otomatis, ukuran kertas, peringatan stok, suara kasir, keamanan, backup, dan mode gelap.
- Printer thermal Bluetooth 58/80 mm melalui `print_bluetooth_thermal`.

## GitHub Build
Ekstrak ZIP dan upload seluruh isinya langsung ke root repository. GitHub Actions akan membuat project Android, mengambil dependency, menjalankan analyze/test, lalu membuat APK release.

## Printer
Pasangkan printer thermal Bluetooth terlebih dahulu di Pengaturan Bluetooth Android. Di aplikasi buka **Pengaturan → Printer & Struk → Cari perangkat printer**, pilih perangkat, lalu hubungkan. API paket printer menyediakan daftar perangkat yang sudah dipasangkan, koneksi, status koneksi, dan cetak teks. citeturn985790search2turn985790search4
