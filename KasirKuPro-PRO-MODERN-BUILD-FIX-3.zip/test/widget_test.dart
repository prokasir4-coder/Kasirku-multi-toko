import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('Cashier page opens in professional POS mode', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: CashierPage(
          products: <Product>[],
          onNeedProduct: () {},
        ),
      ),
    );
    await tester.pump();
    expect(find.text('Kasir siap digunakan'), findsOneWidget);
    expect(find.text('Cari nama / SKU...'), findsOneWidget);
  });
}
