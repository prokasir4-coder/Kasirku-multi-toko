import 'package:flutter/material.dart';

void main() {
  runApp(const KasirKuProApp());
}

class KasirKuProApp extends StatelessWidget {
  const KasirKuProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KasirKuPro',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        scaffoldBackgroundColor: const Color(0xFFF6F8FC),
        fontFamily: 'sans',
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;

  final pages = const [
    DashboardPage(),
    ProductsPage(),
    TransactionsPage(),
    SettingsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Produk'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transaksi'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Pengaturan'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('KasirKuPro', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                  SizedBox(height: 4),
                  Text('Toko Utama', style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            CircleAvatar(
              radius: 22,
              child: Icon(Icons.storefront),
            ),
          ],
        ),
        const SizedBox(height: 22),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: Theme.of(context).colorScheme.primary,
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Penjualan Hari Ini', style: TextStyle(color: Colors.white70)),
              SizedBox(height: 8),
              Text('Rp 4.850.000', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w800)),
              SizedBox(height: 8),
              Text('+12,5% dari kemarin', style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const Row(
          children: [
            Expanded(child: StatCard(title: 'Transaksi', value: '128', icon: Icons.receipt_long)),
            SizedBox(width: 12),
            Expanded(child: StatCard(title: 'Produk Terjual', value: '342', icon: Icons.shopping_bag)),
          ],
        ),
        const SizedBox(height: 22),
        const Text('Menu Cepat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        const Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            QuickAction(icon: Icons.point_of_sale, title: 'Kasir'),
            QuickAction(icon: Icons.add_box, title: 'Tambah Produk'),
            QuickAction(icon: Icons.inventory, title: 'Stok'),
            QuickAction(icon: Icons.bar_chart, title: 'Laporan'),
          ],
        ),
        const SizedBox(height: 24),
        const Text('Transaksi Terbaru', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        ...[
          ('TRX-00128', 'Rp 125.000', '08:42'),
          ('TRX-00127', 'Rp 340.000', '08:31'),
          ('TRX-00126', 'Rp 89.500', '08:15'),
        ].map((e) => ListTile(
          contentPadding: EdgeInsets.zero,
          leading: CircleAvatar(child: Icon(Icons.receipt_long)),
          title: Text(e.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(e.$3),
          trailing: Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
        )),
      ],
    );
  }
}

class StatCard extends StatelessWidget {
  final String title, value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) => Card(
    elevation: 0,
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 12),
        Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        Text(title, style: const TextStyle(color: Colors.grey)),
      ]),
    ),
  );
}

class QuickAction extends StatelessWidget {
  final IconData icon;
  final String title;
  const QuickAction({super.key, required this.icon, required this.title});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 150,
    child: Card(
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Icon(icon, color: Theme.of(context).colorScheme.primary),
          const SizedBox(width: 10),
          Flexible(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))),
        ]),
      ),
    ),
  );
}

class ProductsPage extends StatelessWidget {
  const ProductsPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Produk', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      TextField(
        decoration: InputDecoration(
          hintText: 'Cari produk...',
          prefixIcon: const Icon(Icons.search),
          filled: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 16),
      ...[
        ('Kopi Susu', 'Rp 18.000', 'Stok 42'),
        ('Mie Goreng', 'Rp 15.000', 'Stok 28'),
        ('Air Mineral', 'Rp 5.000', 'Stok 96'),
        ('Teh Manis', 'Rp 7.000', 'Stok 55'),
      ].map((p) => Card(
        elevation: 0,
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.inventory_2)),
          title: Text(p.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text(p.$3),
          trailing: Text(p.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      )),
    ],
  );
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('Transaksi', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
      const SizedBox(height: 16),
      ...List.generate(8, (i) => Card(
        elevation: 0,
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
          title: Text('TRX-${128-i}', style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('Hari ini • ${8 + (i % 3)}:${10 + i}'),
          trailing: Text('Rp ${(125 + i * 35)}.000', style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
      )),
    ],
  );
}


class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  String storeName = 'Toko Utama';
  String ownerName = 'Pemilik Toko';
  String phone = '0812 3456 7890';
  String address = 'Jl. Contoh No. 10, Indonesia';
  String printerStatus = 'Belum terhubung';
  bool autoPrint = true;
  bool soundEnabled = true;
  bool showLowStock = true;
  bool taxEnabled = true;
  bool receiptLogo = true;
  bool darkMode = false;
  int taxPercent = 11;

  void _openStoreProfile() {
    final nameController = TextEditingController(text: storeName);
    final ownerController = TextEditingController(text: ownerName);
    final phoneController = TextEditingController(text: phone);
    final addressController = TextEditingController(text: address);

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          4,
          20,
          MediaQuery.of(sheetContext).viewInsets.bottom + 24,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Profil Toko',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              const Text(
                'Identitas toko yang tampil di struk dan dashboard.',
                style: TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 18),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'Nama toko',
                  prefixIcon: Icon(Icons.storefront_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: ownerController,
                decoration: const InputDecoration(
                  labelText: 'Nama pemilik',
                  prefixIcon: Icon(Icons.person_outline),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Nomor telepon',
                  prefixIcon: Icon(Icons.phone_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: addressController,
                minLines: 2,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Alamat toko',
                  prefixIcon: Icon(Icons.location_on_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () {
                  setState(() {
                    storeName = nameController.text.trim().isEmpty
                        ? 'Toko Utama'
                        : nameController.text.trim();
                    ownerName = ownerController.text.trim().isEmpty
                        ? 'Pemilik Toko'
                        : ownerController.text.trim();
                    phone = phoneController.text.trim();
                    address = addressController.text.trim();
                  });
                  Navigator.pop(sheetContext);
                },
                icon: const Icon(Icons.check),
                label: const Text('Simpan perubahan'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openPrinter() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Printer & Struk',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 6),
              Text(
                printerStatus == 'Belum terhubung'
                    ? 'Hubungkan printer thermal Bluetooth/USB.'
                    : printerStatus,
                style: const TextStyle(color: Colors.grey),
              ),
              const SizedBox(height: 16),
              Card(
                elevation: 0,
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Theme.of(context)
                        .colorScheme
                        .primaryContainer,
                    child: Icon(
                      printerStatus == 'Belum terhubung'
                          ? Icons.print_disabled_outlined
                          : Icons.print_outlined,
                    ),
                  ),
                  title: Text(
                    printerStatus == 'Belum terhubung'
                        ? 'Belum ada printer'
                        : printerStatus,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: const Text('Status koneksi'),
                  trailing: OutlinedButton(
                    onPressed: () {
                      setSheetState(() {
                        printerStatus = 'Printer Kasir 58mm';
                      });
                      setState(() {});
                    },
                    child: Text(
                      printerStatus == 'Belum terhubung'
                          ? 'Hubungkan'
                          : 'Ganti',
                    ),
                  ),
                ),
              ),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: autoPrint,
                onChanged: (value) {
                  setSheetState(() => autoPrint = value);
                  setState(() {});
                },
                title: const Text('Cetak otomatis'),
                subtitle: const Text('Cetak struk setelah pembayaran'),
              ),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: receiptLogo,
                onChanged: (value) {
                  setSheetState(() => receiptLogo = value);
                  setState(() {});
                },
                title: const Text('Tampilkan logo'),
                subtitle: const Text('Logo toko di bagian atas struk'),
              ),
              const SizedBox(height: 8),
              FilledButton.tonalIcon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Tes cetak dikirim.')),
                  );
                },
                icon: const Icon(Icons.print),
                label: const Text('Tes cetak'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openTaxAndDiscount() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Pajak & Diskon',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(height: 16),
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                value: taxEnabled,
                onChanged: (value) {
                  setSheetState(() => taxEnabled = value);
                  setState(() {});
                },
                title: const Text('Aktifkan pajak'),
                subtitle: const Text('Tambahkan pajak pada transaksi'),
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.percent_outlined),
                title: const Text('Persentase pajak'),
                trailing: DropdownButton<int>(
                  value: taxPercent,
                  items: const [0, 5, 10, 11, 12]
                      .map(
                        (value) => DropdownMenuItem(
                          value: value,
                          child: Text('$value%'),
                        ),
                      )
                      .toList(),
                  onChanged: taxEnabled
                      ? (value) {
                          if (value == null) return;
                          setSheetState(() => taxPercent = value);
                          setState(() {});
                        }
                      : null,
                ),
              ),
              const Divider(),
              const ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(Icons.discount_outlined),
                title: Text('Diskon produk'),
                subtitle: Text('Atur diskon dari halaman produk/transaksi'),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: () => Navigator.pop(sheetContext),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                ),
                child: const Text('Selesai'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showInfo(String title, String message) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 10, top: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 3),
          Text(
            subtitle,
            style: const TextStyle(fontSize: 13, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _settingsCard(List<Widget> children) {
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }

  Widget _settingTile({
    required IconData icon,
    required String title,
    String? subtitle,
    VoidCallback? onTap,
    Widget? trailing,
  }) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      leading: CircleAvatar(
        backgroundColor:
            Theme.of(context).colorScheme.surfaceContainerHighest,
        child: Icon(icon),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: subtitle == null ? null : Text(subtitle),
      trailing: trailing ??
          (onTap == null
              ? null
              : const Icon(Icons.chevron_right_rounded)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        Row(
          children: [
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Pengaturan',
                    style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Kelola toko, kasir, transaksi, dan sistem.',
                    style: TextStyle(color: Colors.grey),
                  ),
                ],
              ),
            ),
            CircleAvatar(
              radius: 24,
              backgroundColor:
                  Theme.of(context).colorScheme.primaryContainer,
              child: Icon(
                Icons.settings,
                color: Theme.of(context).colorScheme.onPrimaryContainer,
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        // Profile card
        Card(
          elevation: 0,
          child: InkWell(
            onTap: _openStoreProfile,
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor:
                        Theme.of(context).colorScheme.primaryContainer,
                    child: Icon(
                      Icons.storefront_rounded,
                      color: Theme.of(context)
                          .colorScheme
                          .onPrimaryContainer,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          storeName,
                          style: const TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          '$ownerName • $phone',
                          style: const TextStyle(color: Colors.grey),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          address,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.edit_outlined),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 22),

        _sectionTitle(
          'Toko',
          'Identitas dan perangkat operasional toko.',
        ),
        _settingsCard([
          _settingTile(
            icon: Icons.store_outlined,
            title: 'Profil Toko',
            subtitle: '$storeName • $phone',
            onTap: _openStoreProfile,
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.print_outlined,
            title: 'Printer & Struk',
            subtitle: '$printerStatus • ${autoPrint ? "Cetak otomatis" : "Manual"}',
            onTap: _openPrinter,
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.point_of_sale_outlined,
            title: 'Metode Pembayaran',
            subtitle: 'Tunai, QRIS, transfer, kartu',
            onTap: () => _showInfo(
              'Metode Pembayaran',
              'Menu ini siap dikembangkan untuk mengatur metode pembayaran '
              'yang tersedia di kasir.',
            ),
          ),
        ]),
        const SizedBox(height: 20),

        _sectionTitle(
          'Penjualan',
          'Aturan harga, pajak, diskon, dan notifikasi.',
        ),
        _settingsCard([
          _settingTile(
            icon: Icons.percent_outlined,
            title: 'Pajak & Diskon',
            subtitle: taxEnabled ? 'Pajak aktif $taxPercent%' : 'Pajak nonaktif',
            onTap: _openTaxAndDiscount,
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.notifications_active_outlined,
            title: 'Peringatan Stok',
            subtitle: showLowStock
                ? 'Notifikasi stok menipis aktif'
                : 'Notifikasi stok menipis nonaktif',
            trailing: Switch.adaptive(
              value: showLowStock,
              onChanged: (value) => setState(() => showLowStock = value),
            ),
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.volume_up_outlined,
            title: 'Suara Kasir',
            subtitle: soundEnabled ? 'Suara transaksi aktif' : 'Suara dimatikan',
            trailing: Switch.adaptive(
              value: soundEnabled,
              onChanged: (value) => setState(() => soundEnabled = value),
            ),
          ),
        ]),
        const SizedBox(height: 20),

        _sectionTitle(
          'Akses & Data',
          'Kelola akun pengguna serta keamanan data kasir.',
        ),
        _settingsCard([
          _settingTile(
            icon: Icons.badge_outlined,
            title: 'Pengguna & Kasir',
            subtitle: '1 pemilik • 2 kasir',
            onTap: () => _showInfo(
              'Pengguna & Kasir',
              'Kelola role pemilik, kasir, dan hak akses menu pada versi '
              'produksi aplikasi.',
            ),
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.lock_outline,
            title: 'Keamanan & PIN',
            subtitle: 'PIN kasir dan penguncian aplikasi',
            onTap: () => _showInfo(
              'Keamanan & PIN',
              'Atur PIN kasir, auto-lock, dan izin akses menu penting agar '
              'transaksi lebih aman.',
            ),
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.cloud_upload_outlined,
            title: 'Backup & Pulihkan',
            subtitle: 'Simpan data transaksi dan produk',
            onTap: () => _showInfo(
              'Backup & Pulihkan',
              'Fitur ini dapat dihubungkan ke penyimpanan lokal atau cloud '
              'untuk backup data toko secara berkala.',
            ),
          ),
        ]),
        const SizedBox(height: 20),

        _sectionTitle(
          'Tampilan',
          'Sesuaikan pengalaman penggunaan aplikasi.',
        ),
        _settingsCard([
          _settingTile(
            icon: Icons.dark_mode_outlined,
            title: 'Mode Gelap',
            subtitle: darkMode ? 'Tampilan gelap aktif' : 'Mengikuti tampilan terang',
            trailing: Switch.adaptive(
              value: darkMode,
              onChanged: (value) {
                setState(() => darkMode = value);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      value
                          ? 'Mode gelap dipilih. Tema global dapat diaktifkan di versi berikutnya.'
                          : 'Mode terang dipilih.',
                    ),
                  ),
                );
              },
            ),
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.receipt_long_outlined,
            title: 'Format Struk',
            subtitle: receiptLogo ? 'Logo + detail toko + total' : 'Tanpa logo',
            onTap: _openPrinter,
          ),
        ]),
        const SizedBox(height: 20),

        _sectionTitle(
          'Aplikasi',
          'Informasi dan dukungan KasirKuPro.',
        ),
        _settingsCard([
          _settingTile(
            icon: Icons.info_outline,
            title: 'Tentang KasirKuPro',
            subtitle: 'Versi 1.0.0 • Build 1',
            onTap: () => _showInfo(
              'KasirKuPro',
              'Aplikasi kasir modern untuk membantu pencatatan produk, '
              'transaksi, dan pengelolaan toko.',
            ),
          ),
          const Divider(height: 1),
          _settingTile(
            icon: Icons.help_outline,
            title: 'Bantuan & Dukungan',
            subtitle: 'Panduan penggunaan aplikasi',
            onTap: () => _showInfo(
              'Bantuan & Dukungan',
              'Tambahkan WhatsApp, email, atau pusat bantuan toko di sini '
              'agar aplikasi siap digunakan pelanggan.',
            ),
          ),
        ]),
        const SizedBox(height: 16),
        const Center(
          child: Text(
            'KasirKuPro • Professional POS',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ),
      ],
    );
  }
}

