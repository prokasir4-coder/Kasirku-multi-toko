import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:kasirku_pro/main.dart';

void main() {
  testWidgets('KasirKuPro tampil', (tester) async {
    await tester.pumpWidget(const KasirKuProApp());
    expect(find.text('KasirKuPro'), findsOneWidget);
    expect(find.text('Penjualan Hari Ini'), findsOneWidget);
  });

  testWidgets('Pengaturan profesional tampil', (tester) async {
    await tester.pumpWidget(const KasirKuProApp());
    await tester.tap(find.byIcon(Icons.settings_outlined));
    await tester.pumpAndSettle();

    expect(find.text('Profil Toko'), findsOneWidget);
    expect(find.text('Printer & Struk'), findsOneWidget);
    expect(find.text('Pajak & Diskon'), findsOneWidget);
    expect(find.text('Pengguna & Kasir'), findsOneWidget);
  });
}
