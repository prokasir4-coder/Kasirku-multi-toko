# KasirKuPro Pro

Aplikasi kasir Flutter modern dengan tampilan profesional dan menu Pengaturan yang lebih lengkap.

## Yang sudah tersedia
- Dashboard penjualan
- Produk
- Transaksi
- Pengaturan profesional:
  - Profil toko
  - Printer & struk
  - Metode pembayaran
  - Pajak & diskon
  - Peringatan stok
  - Suara kasir
  - Pengguna & kasir
  - Keamanan & PIN
  - Backup & pulihkan
  - Mode gelap
  - Format struk
  - Tentang & bantuan
- GitHub Actions untuk build APK otomatis

## Menjalankan lokal

```bash
flutter pub get
flutter run
```

## Build APK dari GitHub

Push project ini ke repository GitHub, lalu buka tab **Actions** dan pilih workflow **Build KasirKuPro APK**.

Setelah workflow selesai dengan status hijau:
1. Buka detail workflow run.
2. Scroll ke bagian **Artifacts**.
3. Download artifact APK.
4. Ekstrak ZIP untuk mendapatkan file `.apk`.

## Catatan

Menu pengaturan sudah dibuat interaktif dengan dialog/bottom sheet dan state lokal sehingga bisa langsung dipakai sebagai basis aplikasi jualan. Penyimpanan permanen, database, koneksi printer nyata, login multi-user, dan backup cloud dapat dihubungkan pada tahap berikutnya.
